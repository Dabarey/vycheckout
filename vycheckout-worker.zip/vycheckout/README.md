# VyCheckout on Cloudflare Workers

The whole app runs on one Cloudflare Worker:

- `public/index.html` is the website (served as a static asset).
- `src/` is the backend at `/api/*`, with a D1 database.
- PayPal and Stripe call `/webhooks/paypal` and `/webhooks/stripe`.

## What changed for security

| Before (Supabase from the browser) | Now (Worker) |
|---|---|
| The browser inserted "succeeded" payments, so anyone could create money | A payment is recorded only after the Worker confirms it with PayPal/Stripe (capture call or signature-checked webhook). Each payment is counted once. |
| The browser chose the price sent to PayPal/Stripe | The Worker creates the order from the price saved in the database |
| The browser wrote `balance` | Balances are a sum of ledger entries the Worker writes. There is no endpoint that sets a balance. |
| Admin = an email check in JavaScript | Admin is checked on the server: a **confirmed** email listed in `ADMIN_EMAILS`. Every admin action is written to `audit_log`. |
| API keys stored in plain text | Only a SHA-256 hash is stored. The full key is shown once. |
| Webhooks sent from the payer's browser, unsigned | Sent by the Worker after payment, signed with HMAC-SHA256, retried up to 6 times |
| Two withdrawals at once could overdraw | The balance check and the withdrawal insert are one SQL statement |
| Stored XSS in admin bank details | All user text is escaped. Bank details are limited to known fields. |

Other protections:

- **Sessions:** HttpOnly, Secure, SameSite cookies.
- **Requests:** the Worker blocks cross-site requests (CSRF protection).
- **Rate limits:** on login, signup, password reset, withdrawals, orders and the API.
- **Passwords:** stored as PBKDF2 hashes.
- **Password reset:** signs out every other session.
- **Google sign-in:** if someone else registered your email before confirming it, signing in with Google removes their password and signs them out.
- **Refunds and chargebacks:** reverse the merchant's share and the referral automatically.
- **Money:** amounts are whole cents (whole yen for JPY), and each currency has its own balance.

## Deploy (about 20 minutes)

You need Node.js 20+ and a Cloudflare account.

```bash
npm install
npx wrangler login
npx wrangler d1 create vycheckout
```

Copy the `database_id` it prints into `wrangler.jsonc`, then create the tables:

```bash
npm run db:remote
```

In `wrangler.jsonc` → `vars`, set:

- `APP_URL`: the address people will use, e.g. `https://vycheckout.com`. If you don't have a domain yet, use your `https://vycheckout.<you>.workers.dev` URL.
- `ADMIN_EMAILS`: your admin email(s), comma-separated.
- `EMAIL_FROM`: the sender address for emails (it must be on a domain you verify in Resend).
- `PAYPAL_CLIENT_ID` / `STRIPE_PUBLISHABLE_KEY`: already filled with your live public keys. Use sandbox/test keys while testing.

Add the secrets. Each command asks you to paste the value:

```bash
npx wrangler secret put PAYPAL_CLIENT_SECRET
npx wrangler secret put PAYPAL_WEBHOOK_ID       # from step 2 below
npx wrangler secret put STRIPE_SECRET_KEY
npx wrangler secret put STRIPE_WEBHOOK_SECRET   # from step 3 below
npx wrangler secret put RESEND_API_KEY          # for confirmation and password-reset emails
npx wrangler secret put GOOGLE_CLIENT_ID        # optional, for "Continue with Google"
npx wrangler secret put GOOGLE_CLIENT_SECRET
```

Then deploy:

```bash
npm run deploy
```

### 1. Custom domain (optional)

Go to Cloudflare dashboard → Workers & Pages → vycheckout → Settings → Domains & Routes → Add custom domain. Then update `APP_URL` and deploy again.

### 2. PayPal webhook

1. Go to developer.paypal.com → Apps & Credentials → your app → Webhooks → Add webhook.
2. Set the URL to `https://YOUR-DOMAIN/webhooks/paypal`.
3. Choose these events: `PAYMENT.CAPTURE.COMPLETED`, `PAYMENT.CAPTURE.REFUNDED`, `PAYMENT.CAPTURE.REVERSED`.
4. Copy the **Webhook ID** and save it with `npx wrangler secret put PAYPAL_WEBHOOK_ID`.

### 3. Stripe webhook

1. Go to dashboard.stripe.com → Developers → Webhooks → Add endpoint.
2. Set the URL to `https://YOUR-DOMAIN/webhooks/stripe`.
3. Choose these events: `payment_intent.succeeded`, `charge.refunded`, `charge.dispute.funds_withdrawn`.
4. Copy the **Signing secret** (`whsec_…`) and save it with `npx wrangler secret put STRIPE_WEBHOOK_SECRET`.

### 4. Email (Resend)

1. Sign up at resend.com and verify your domain.
2. Create an API key and save it as `RESEND_API_KEY`.

Without this, nobody receives email-confirmation or password-reset links. Confirming an email is required before withdrawing money and before an admin email gets admin rights.

### 5. Google sign-in (optional)

1. Go to console.cloud.google.com → APIs & Services → Credentials → Create OAuth client ID (Web application).
2. Add this authorised redirect URI: `https://YOUR-DOMAIN/api/auth/google/callback`.
3. Save the client ID and secret as the two `GOOGLE_*` secrets.

The Google button stays off until both are set.

### 6. Become admin

1. Sign up with an email listed in `ADMIN_EMAILS`.
2. Click the confirmation link in your email, or use "Continue with Google".
3. Reload the page and the admin panel appears.

An unconfirmed signup with the admin email gets no admin rights.

### 7. Turn off the old Supabase backend

The old `stripe-setup` and `notify` Edge Functions are still public. Delete them, then pause the Supabase project once you have moved over.

## Test before going live

1. Set `PAYPAL_ENV` to `sandbox` and use your PayPal **sandbox** client ID and secret.
2. Use Stripe **test** keys (`pk_test_…`, `sk_test_…`).
3. Pay a link with a sandbox account and a test card (`4242 4242 4242 4242`).
4. Check that the payment appears and the balance updates.
5. Refund it from the PayPal or Stripe dashboard, and check that the balance goes back down.
6. Switch to live keys.

### Running it on your computer

```bash
cp .dev.vars.example .dev.vars   # fill in sandbox/test keys
npm run db:local
npm run dev                      # http://localhost:8787
```

With `DEV=true` and no `RESEND_API_KEY`, the confirmation and reset links are printed in the terminal.

## Merchant API

Send `Authorization: Bearer vy_live_…` (created in the dashboard → API Keys):

- `GET /api/v1/balance`
- `GET /api/v1/transactions?limit=50`
- `POST /api/v1/collections` with `{"name","amount","currency","description"}` or `{"custom_amount":true}`
- `POST /api/v1/links` with `{"name","amount","currency","note","expires_days"}`

### Merchant webhooks

Events are `payment.succeeded` and `payment.refunded`. Each request has the header `VyCheckout-Signature: t=<unix time>,v1=<hex>`, where `v1 = HMAC-SHA256(signing secret, t + "." + raw body)`.

## Settings you can change (`vars`)

| Name | Default | Meaning |
|---|---|---|
| `PLATFORM_FEE_BPS` | 2400 | Platform fee in basis points (2400 = 24%) |
| `REFERRAL_BPS` | 100 | Referral commission paid from the platform fee (100 = 1%) |
| `MIN_WITHDRAW_PAYPAL` / `MIN_WITHDRAW_BANK` | 100 / 500 | Minimum withdrawal in the currency's main unit (×100 for JPY) |
| `MAX_PAYMENT` | 10000 | Largest single payment or item price |

## Not done yet

- **Subscriptions charge once.** Automatic renewal needs PayPal subscription plans or Stripe Billing.
- **Existing Supabase users and data are not copied over.** This deployment starts with an empty database.
- **Payouts are still manual.** The admin approves them and marks them paid after sending the money.
- **Collecting all payments in your own PayPal/Stripe account and paying merchants later may break PayPal's and Stripe's terms.** Look at Stripe Connect or PayPal's marketplace products.

## If PayPal or card buttons don't appear

`public/_headers` sets a Content-Security-Policy. If your browser console shows a "Refused to load" error from PayPal or Stripe, add that domain to the matching line in `public/_headers` and deploy again.
