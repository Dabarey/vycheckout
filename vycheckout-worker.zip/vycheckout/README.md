# VyCheckout on Cloudflare Workers

The whole app runs on one Cloudflare Worker:

- `public/index.html` is the website (served as a static asset).
- `src/` is the backend at `/api/*`, with a D1 database.
- PayPal and Stripe call `/webhooks/paypal` and `/webhooks/stripe`.

## What changed for security

| Before (Supabase from the browser) | Now (Worker) |
|---|---|
| The browser inserted "succeeded" payments, so anyone could create money | A payment is recorded only after the Worker confirms it with PayPal/Stripe (capture call or signature-checked webhook). Each payment is counted once. |
| The browser chose the price sent to PayPal/Stripe | The Worker creates the order from the price saved in the database |
| The browser wrote `balance` | Balances are a sum of ledger entries the Worker writes. There is no endpoint that sets a balance. |
| Admin = an email check in JavaScript | Admin is checked on the server: a **confirmed** email listed in `ADMIN_EMAILS`. Every admin action is written to `audit_log`. |
| API keys stored in plain text | Only a SHA-256 hash is stored. The full key is shown once. |
| Webhooks sent from the payer's browser, unsigned | Sent by the Worker after payment, signed with HMAC-SHA256, retried up to 6 times |
| Two withdrawals at once could overdraw | The balance check and the withdrawal insert are one SQL statement |
| Stored XSS in admin bank details | All user text is escaped. Bank details are limited to known fields. |

Other protections:

- **Sessions:** HttpOnly, Secure, SameSite cookies.
- **Requests:** the Worker blocks cross-site requests (CSRF protection).
- **Rate limits:** on login, signup, password reset, withdrawals, orders and the API.
- **Passwords:** stored as PBKDF2 hashes.
- **Password reset:** signs out every other session.
- **Google sign-in:** if someone else registered your email before confirming it, signing in with Google removes their password and signs them out.
- **Refunds and chargebacks:** reverse the merchant's share and the referral automatically.
- **Money:** amounts are whole cents (whole yen for JPY), and each currency has its own balance.

## Features added in this version

- **Payment hold.** New money waits before it can be withdrawn: 7 days normally, 14 days for accounts under 30 days old. The admin can change it per merchant (Users → ⏳ Hold). Merchants see "Available" and "On hold" with the release date. Refunds during the hold come out of the held money.
- **Bot check (Cloudflare Turnstile).** Required for signup, login, password reset and anonymous payments. Solving it once gives a 30-minute pass, and it's usually invisible.
- **19% platform fee,** shown on the landing page, the signup page, the create forms and in the Terms.
- **Emails.** The payer gets a receipt, and the merchant gets "You got paid" (they can turn it off in Account). Merchants also get updates when a withdrawal is approved, paid or rejected.
- **Card payments on the public checkout page,** next to PayPal.
- **Real recurring subscriptions.** Payers subscribe with Stripe Billing (card) or PayPal Subscriptions. Every renewal is checked with the provider before it's recorded. Subscribers cancel from the link in their receipt email. Merchants see their subscribers and can cancel them, and deleting a plan cancels everyone on it.
- **Account settings:** change email (needs the current password; the new address must be confirmed), change or set a password, turn payment emails on or off, sign out everywhere, and delete the account (blocked while there's money in it).
- **Admin alerts by email** (and Slack or Discord if `ALERT_WEBHOOK_URL` is set):
  - Sent right away for: payment amount mismatches, disputes and chargebacks, failed PayPal payouts, and merchant balances that go negative after a refund.
  - Sent once a day (about 8:30 am Sri Lanka time): last 24 hours of payments, the withdrawal queue, and anything that needs attention.
- **One-click PayPal payouts.** For an approved PayPal withdrawal, press "💸 Send with PayPal". The status updates automatically (webhook, plus a check every 5 minutes), and the request is marked paid when PayPal confirms it. A payout can't be sent twice or rejected while it's on its way. Bank transfers stay manual.

## Deploy (about 30 minutes)

You need Node.js 20+ and a Cloudflare account.

```bash
npm install
npx wrangler login
npx wrangler d1 create vycheckout
```

Copy the `database_id` it prints into `wrangler.jsonc`, then create the tables:

```bash
npm run db:remote
```

In `wrangler.jsonc` → `vars`, set:

- `APP_URL`: the address people will use, e.g. `https://vycheckout.com`. If you don't have a domain yet, use your `https://vycheckout.<you>.workers.dev` URL.
- `ADMIN_EMAILS`: your admin email(s), comma-separated.
- `EMAIL_FROM`: the sender address for emails (it must be on a domain you verify in Resend).
- `PAYPAL_CLIENT_ID` / `STRIPE_PUBLISHABLE_KEY`: already filled with your live public keys. Use sandbox/test keys while testing.
- `TURNSTILE_SITE_KEY`: from step 6 below.

Add the secrets. Each command asks you to paste the value:

```bash
npx wrangler secret put PAYPAL_CLIENT_SECRET
npx wrangler secret put PAYPAL_WEBHOOK_ID       # from step 2 below
npx wrangler secret put STRIPE_SECRET_KEY
npx wrangler secret put STRIPE_WEBHOOK_SECRET   # from step 3 below
npx wrangler secret put RESEND_API_KEY          # for confirmation and password-reset emails
npx wrangler secret put GOOGLE_CLIENT_ID        # optional, for "Continue with Google"
npx wrangler secret put GOOGLE_CLIENT_SECRET
npx wrangler secret put TURNSTILE_SECRET_KEY    # bot check, step 6 below
npx wrangler secret put ALERT_WEBHOOK_URL       # optional: Slack/Discord incoming webhook for admin alerts
```

Then deploy:

```bash
npm run deploy
```

### 1. Custom domain (optional)

Go to Cloudflare dashboard → Workers & Pages → vycheckout → Settings → Domains & Routes → Add custom domain. Then update `APP_URL` and deploy again.

### 2. PayPal webhook

1. Go to developer.paypal.com → Apps & Credentials → your app → Webhooks → Add webhook.
2. Set the URL to `https://YOUR-DOMAIN/webhooks/paypal`.
3. Choose these events:
   - One-time payments: `PAYMENT.CAPTURE.COMPLETED`, `PAYMENT.CAPTURE.REFUNDED`, `PAYMENT.CAPTURE.REVERSED`
   - Subscriptions: `PAYMENT.SALE.COMPLETED`, `PAYMENT.SALE.REFUNDED`, `PAYMENT.SALE.REVERSED`, `BILLING.SUBSCRIPTION.ACTIVATED`, `BILLING.SUBSCRIPTION.CANCELLED`, `BILLING.SUBSCRIPTION.SUSPENDED`, `BILLING.SUBSCRIPTION.EXPIRED`, `BILLING.SUBSCRIPTION.PAYMENT.FAILED`
   - Payouts: all `PAYMENT.PAYOUTS-ITEM.*` events
   - Disputes: `CUSTOMER.DISPUTE.CREATED`
4. Copy the **Webhook ID** and save it with `npx wrangler secret put PAYPAL_WEBHOOK_ID`.

### 3. Stripe webhook

1. Go to dashboard.stripe.com → Developers → Webhooks → Add endpoint.
2. Set the URL to `https://YOUR-DOMAIN/webhooks/stripe`.
3. Choose these events: `payment_intent.succeeded`, `charge.refunded`, `charge.dispute.created`, `charge.dispute.funds_withdrawn`, `invoice.paid`, `invoice.payment_failed`, `customer.subscription.updated`, `customer.subscription.deleted`.
4. Copy the **Signing secret** (`whsec_…`) and save it with `npx wrangler secret put STRIPE_WEBHOOK_SECRET`.

### 4. Email (Resend)

1. Sign up at resend.com and verify your domain.
2. Create an API key and save it as `RESEND_API_KEY`.

Without this, nobody receives email-confirmation or password-reset links. Confirming an email is required before withdrawing money and before an admin email gets admin rights.

### 5. Google sign-in (optional)

1. Go to console.cloud.google.com → APIs & Services → Credentials → Create OAuth client ID (Web application).
2. Add this authorised redirect URI: `https://YOUR-DOMAIN/api/auth/google/callback`.
3. Save the client ID and secret as the two `GOOGLE_*` secrets.

The Google button stays off until both are set.

### 6. Bot check (Cloudflare Turnstile)

1. Go to Cloudflare dashboard → Turnstile → Add widget.
2. Add your domain and choose the **Managed** mode.
3. Put the **Site key** in `TURNSTILE_SITE_KEY` in `wrangler.jsonc`, and save the **Secret key** with `npx wrangler secret put TURNSTILE_SECRET_KEY`.

The check stays off until both are set.

### 7. PayPal Payouts (for one-click payouts)

PayPal has to enable Payouts on your account: go to developer.paypal.com → your live app → Features → Payouts, or ask PayPal support. Until it's enabled, "Send with PayPal" shows PayPal's error, and you can still pay by hand and press "Mark as Paid".

### 8. Stripe Radar

In the Stripe dashboard → Radar → Rules, keep the default rules on. Consider adding "Block if CVC check fails" and "Block if postal code check fails" to stop card testing.

### 9. Become admin

1. Sign up with an email listed in `ADMIN_EMAILS`.
2. Click the confirmation link in your email, or use "Continue with Google".
3. Reload the page and the admin panel appears.

An unconfirmed signup with the admin email gets no admin rights.

### 10. Delete the old Supabase backend

Do this after the new site is live and working, because the old page stops working once Supabase is gone.

1. **Export anything you want to keep** (Supabase → Table Editor → each table → Export to CSV), or ask for a migration script.
2. **Delete the Edge Functions:** Supabase → Edge Functions → `stripe-setup` → ⋯ → Delete, and the same for `notify` and any other function.
3. **Rotate the keys those functions used.** In Stripe (Developers → API keys → "Roll" the secret key), put the new key into the Worker with `npx wrangler secret put STRIPE_SECRET_KEY`. Do the same for any PayPal secret the old functions used.
4. **Delete the project:** Supabase → Project Settings → General → **Delete project**. Pausing is enough if you want to wait a while first.
5. **Remove its Google sign-in redirect:** Google Cloud console → Credentials → your OAuth client → remove the `…supabase.co/auth/v1/callback` redirect URI.

## Test before going live

1. Set `PAYPAL_ENV` to `sandbox` and use your PayPal **sandbox** client ID and secret.
2. Use Stripe **test** keys (`pk_test_…`, `sk_test_…`).
3. Pay a link with a sandbox account and a test card (`4242 4242 4242 4242`).
4. Check that the payment appears and the balance updates.
5. Refund it from the PayPal or Stripe dashboard, and check that the balance goes back down.
6. Switch to live keys.

### Running it on your computer

```bash
cp .dev.vars.example .dev.vars   # fill in sandbox/test keys
npm run db:local
npm run dev                      # http://localhost:8787
```

With `DEV=true` and no `RESEND_API_KEY`, all emails (confirmation and reset links, receipts, alerts) are printed in the terminal. Without the Turnstile keys, the bot check is off.

## Merchant API

Send `Authorization: Bearer vy_live_…` (created in the dashboard → API Keys):

- `GET /api/v1/balance`
- `GET /api/v1/transactions?limit=50`
- `POST /api/v1/collections` with `{"name","amount","currency","description"}` or `{"custom_amount":true}`
- `POST /api/v1/links` with `{"name","amount","currency","note","expires_days"}`

### Merchant webhooks

Events are `payment.succeeded` and `payment.refunded`. Subscription charges include `subscription_id`. Each request has the header `VyCheckout-Signature: t=<unix time>,v1=<hex>`, where `v1 = HMAC-SHA256(signing secret, t + "." + raw body)`.

## Settings you can change (`vars`)

| Name | Default | Meaning |
|---|---|---|
| `PLATFORM_FEE_BPS` | 1900 | Platform fee in basis points (1900 = 19%) |
| `REFERRAL_BPS` | 100 | Referral commission paid from the platform fee (100 = 1%) |
| `MIN_WITHDRAW_PAYPAL` / `MIN_WITHDRAW_BANK` | 100 / 500 | Minimum withdrawal in the currency's main unit (×100 for JPY) |
| `MAX_PAYMENT` | 10000 | Largest single payment or item price |
| `HOLD_DAYS` | 7 | Days before new money can be withdrawn |
| `NEW_ACCOUNT_HOLD_DAYS` / `NEW_ACCOUNT_DAYS` | 14 / 30 | Longer hold for accounts younger than 30 days |
| `DIGEST_HOUR_UTC` | 3 | Hour (UTC) of the daily admin summary |

## Not done yet

- **Two-step login for admins** (item 3) is not built.
- **Existing Supabase users and data are not copied over.** This deployment starts with an empty database.
- **Bank-transfer payouts are manual.** PayPal payouts are one click.
- **Collecting all payments in your own PayPal/Stripe account and paying merchants later may break PayPal's and Stripe's terms.** Look at Stripe Connect or PayPal's marketplace products.

## If PayPal or card buttons don't appear

`public/_headers` sets a Content-Security-Policy. If your browser console shows a "Refused to load" error from PayPal or Stripe, add that domain to the matching line in `public/_headers` and deploy again.
