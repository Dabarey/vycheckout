-- VyCheckout database (Cloudflare D1 / SQLite)
-- Money is stored as integers in the currency's smallest unit (cents; whole yen for JPY).

CREATE TABLE users (
  id              TEXT PRIMARY KEY,
  email           TEXT NOT NULL UNIQUE COLLATE NOCASE,
  email_verified  INTEGER NOT NULL DEFAULT 0,
  password_hash   TEXT,                       -- NULL for Google-only accounts
  google_sub      TEXT UNIQUE,
  full_name       TEXT NOT NULL DEFAULT '',
  business_name   TEXT NOT NULL DEFAULT '',
  bio             TEXT,
  avatar          TEXT,
  ref_code        TEXT NOT NULL UNIQUE,
  referrer_id     TEXT REFERENCES users(id),
  is_admin        INTEGER NOT NULL DEFAULT 0,
  suspended       INTEGER NOT NULL DEFAULT 0,
  deleted_at      TEXT,
  webhook_url     TEXT,
  webhook_secret  TEXT,
  created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_users_referrer ON users(referrer_id);

CREATE TABLE sessions (
  token_hash  TEXT PRIMARY KEY,               -- SHA-256 of the cookie value
  user_id     TEXT NOT NULL REFERENCES users(id),
  expires_at  INTEGER NOT NULL,               -- unix ms
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

-- One-time tokens for password reset and email verification (stored hashed)
CREATE TABLE auth_tokens (
  token_hash  TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id),
  purpose     TEXT NOT NULL CHECK (purpose IN ('reset','verify')),
  expires_at  INTEGER NOT NULL,
  used_at     TEXT
);

CREATE TABLE api_keys (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL REFERENCES users(id),
  prefix        TEXT NOT NULL,                -- first characters, shown in the dashboard
  key_hash      TEXT NOT NULL UNIQUE,         -- SHA-256 of the full key
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_used_at  TEXT,
  revoked_at    TEXT
);
CREATE INDEX idx_api_keys_user ON api_keys(user_id);

-- Collections (col), subscription plans (sub) and pay links (lnk)
CREATE TABLE items (
  id             TEXT PRIMARY KEY,
  user_id        TEXT NOT NULL REFERENCES users(id),
  type           TEXT NOT NULL CHECK (type IN ('col','sub','lnk')),
  name           TEXT NOT NULL,
  description    TEXT,
  note           TEXT,
  amount_minor   INTEGER NOT NULL DEFAULT 0,
  currency       TEXT NOT NULL,
  cycle          TEXT,
  custom_amount  INTEGER NOT NULL DEFAULT 0,
  expires_at     TEXT,
  source         TEXT NOT NULL DEFAULT 'web',  -- 'web' or 'api'
  deleted_at     TEXT,
  created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_items_user ON items(user_id, created_at);

-- A checkout attempt. The price is fixed here, server-side, before the payer is sent to PayPal/Stripe.
CREATE TABLE orders (
  id                 TEXT PRIMARY KEY,
  item_id            TEXT NOT NULL REFERENCES items(id),
  owner_id           TEXT NOT NULL REFERENCES users(id),
  provider           TEXT NOT NULL CHECK (provider IN ('paypal','stripe')),
  provider_order_id  TEXT UNIQUE,
  amount_minor       INTEGER NOT NULL,
  currency           TEXT NOT NULL,
  status             TEXT NOT NULL DEFAULT 'created',   -- created | paid
  created_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Only verified payments end up here. (provider, provider_ref) is unique, so a payment is never counted twice.
CREATE TABLE transactions (
  id               TEXT PRIMARY KEY,
  owner_id         TEXT NOT NULL REFERENCES users(id),
  item_id          TEXT REFERENCES items(id),
  item_type        TEXT,
  order_id         TEXT REFERENCES orders(id),
  provider         TEXT NOT NULL,
  provider_ref     TEXT NOT NULL,                -- PayPal capture id / Stripe PaymentIntent id
  description      TEXT,
  payer_name       TEXT,
  payer_email      TEXT,
  currency         TEXT NOT NULL,
  gross_minor      INTEGER NOT NULL,
  fee_minor        INTEGER NOT NULL,
  net_minor        INTEGER NOT NULL,
  referrer_id      TEXT REFERENCES users(id),
  referral_minor   INTEGER NOT NULL DEFAULT 0,
  refunded_minor   INTEGER NOT NULL DEFAULT 0,
  status           TEXT NOT NULL DEFAULT 'succeeded',  -- succeeded | partially_refunded | refunded
  created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (provider, provider_ref)
);
CREATE INDEX idx_txn_owner ON transactions(owner_id, created_at);

-- Each refund is applied once, keyed by the provider's refund id
CREATE TABLE refunds (
  id                  TEXT PRIMARY KEY,
  provider            TEXT NOT NULL,
  provider_refund_id  TEXT NOT NULL,
  txn_id              TEXT NOT NULL REFERENCES transactions(id),
  amount_minor        INTEGER NOT NULL,
  created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (provider, provider_refund_id)
);

-- Every change to a user's money is a ledger row. Balance = SUM(ledger) − open/paid withdrawals.
CREATE TABLE ledger (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL REFERENCES users(id),
  currency      TEXT NOT NULL,
  amount_minor  INTEGER NOT NULL,              -- positive = credit, negative = debit
  kind          TEXT NOT NULL CHECK (kind IN ('sale','referral','refund','referral_reversal','adjustment')),
  txn_id        TEXT REFERENCES transactions(id),
  note          TEXT,
  created_by    TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_ledger_user ON ledger(user_id, currency);

CREATE TABLE withdrawals (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL REFERENCES users(id),
  currency      TEXT NOT NULL,
  amount_minor  INTEGER NOT NULL CHECK (amount_minor > 0),
  method        TEXT NOT NULL,                 -- PayPal | Bank Transfer
  destination   TEXT,
  country       TEXT,
  bank_details  TEXT,                          -- JSON
  notes         TEXT,
  status        TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','completed','rejected')),
  admin_note    TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at    TEXT
);
CREATE INDEX idx_wd_user ON withdrawals(user_id, currency);
CREATE INDEX idx_wd_status ON withdrawals(status);

CREATE TABLE follows (
  follower_id   TEXT NOT NULL REFERENCES users(id),
  following_id  TEXT NOT NULL REFERENCES users(id),
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (follower_id, following_id)
);
CREATE INDEX idx_follows_following ON follows(following_id);

-- Signed webhooks to merchants, retried by the cron trigger
CREATE TABLE webhook_deliveries (
  id               TEXT PRIMARY KEY,
  user_id          TEXT NOT NULL REFERENCES users(id),
  url              TEXT NOT NULL,
  event            TEXT NOT NULL,
  payload          TEXT NOT NULL,
  attempts         INTEGER NOT NULL DEFAULT 0,
  status           TEXT NOT NULL DEFAULT 'pending',   -- pending | delivered | failed
  next_attempt_at  INTEGER NOT NULL,
  last_error       TEXT,
  created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX idx_wh_due ON webhook_deliveries(status, next_attempt_at);

CREATE TABLE rate_limits (
  key           TEXT PRIMARY KEY,
  count         INTEGER NOT NULL,
  window_start  INTEGER NOT NULL
);

CREATE TABLE audit_log (
  id          TEXT PRIMARY KEY,
  actor_id    TEXT,
  action      TEXT NOT NULL,
  target      TEXT,
  details     TEXT,
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
