-- Payment hold, subscriptions, account settings, PayPal payouts, alerts

-- Payment hold: money becomes withdrawable at available_at (NULL = available now)
ALTER TABLE ledger ADD COLUMN available_at TEXT;
CREATE INDEX idx_ledger_available ON ledger(user_id, currency, available_at);

ALTER TABLE users ADD COLUMN hold_days INTEGER;                       -- admin override; NULL = default rules
ALTER TABLE users ADD COLUMN notify_sales INTEGER NOT NULL DEFAULT 1; -- email the merchant on each sale

-- Provider objects created once per subscription plan
ALTER TABLE items ADD COLUMN stripe_product_id TEXT;
ALTER TABLE items ADD COLUMN paypal_product_id TEXT;
ALTER TABLE items ADD COLUMN paypal_plan_id TEXT;

ALTER TABLE transactions ADD COLUMN subscription_id TEXT;

-- PayPal Payouts tracking for withdrawals
ALTER TABLE withdrawals ADD COLUMN payout_batch_id TEXT;
ALTER TABLE withdrawals ADD COLUMN payout_status TEXT;   -- PENDING | SUCCESS | FAILED | UNCLAIMED | ...
ALTER TABLE withdrawals ADD COLUMN payout_error TEXT;

-- Recurring subscriptions (one row per subscriber)
CREATE TABLE subscriptions (
  id                  TEXT PRIMARY KEY,
  item_id             TEXT NOT NULL REFERENCES items(id),
  owner_id            TEXT NOT NULL REFERENCES users(id),
  provider            TEXT NOT NULL CHECK (provider IN ('paypal','stripe')),
  provider_sub_id     TEXT UNIQUE,
  stripe_customer_id  TEXT,
  payer_email         TEXT NOT NULL,
  payer_name          TEXT,
  amount_minor        INTEGER NOT NULL,
  currency            TEXT NOT NULL,
  cycle               TEXT NOT NULL,
  status              TEXT NOT NULL DEFAULT 'pending',   -- pending | active | past_due | cancelled
  cancel_token        TEXT,                              -- lets the subscriber cancel from their email
  created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  activated_at        TEXT,
  cancelled_at        TEXT
);
CREATE INDEX idx_subs_owner ON subscriptions(owner_id, status);
CREATE INDEX idx_subs_item ON subscriptions(item_id);

-- Small key/value store (alert bookkeeping)
CREATE TABLE settings (
  key    TEXT PRIMARY KEY,
  value  TEXT
);
