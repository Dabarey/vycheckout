// Recurring subscriptions: Stripe Billing (card) and PayPal Subscriptions.
// Every renewal charge is checked with the provider before it is recorded, like one-time payments.
import { HttpError, bad, notFound, forbidden, json, readJson, newId, nowIso, toMinor, toMajor, majorString, str, emailOf, randomToken, audit } from './lib.js';
import { requireUser } from './auth.js';
import { payableItem, guardPayer, recordPayment, applyRefund, receiptView, pp, stripe, appUrl } from './payments.js';
import { alert } from './email.js';

const CYCLES = {
  WEEKLY:    { stripe: ['week', 1],  paypal: ['WEEK', 1] },
  MONTHLY:   { stripe: ['month', 1], paypal: ['MONTH', 1] },
  QUARTERLY: { stripe: ['month', 3], paypal: ['MONTH', 3] },
  ANNUALLY:  { stripe: ['year', 1],  paypal: ['YEAR', 1] },
};
const cycleOf = c => CYCLES[c] || CYCLES.MONTHLY;
const cancelUrl = (env, row) => `${(env.APP_URL || '').replace(/\/$/, '')}/?cancel_sub=${encodeURIComponent(row.cancel_token)}`;

// The charge each renewal must match
const orderFor = row => ({ id: null, owner_id: row.owner_id, item_id: row.item_id, amount_minor: row.amount_minor, currency: row.currency });

async function startRow(env, request, provider) {
  const b = await readJson(request);
  await guardPayer(env, request);
  const item = await payableItem(env, b.item_id);
  if (item.type !== 'sub') throw bad('This link is not a subscription');
  const row = {
    id: newId(), item_id: item.id, owner_id: item.user_id, provider,
    payer_email: emailOf(b.email), payer_name: str(b.name, { max: 120, field: 'Name' }) || null,
    amount_minor: item.amount_minor, currency: item.currency, cycle: item.cycle || 'MONTHLY', cancel_token: randomToken(24),
  };
  await env.DB.prepare(
    `INSERT INTO subscriptions (id, item_id, owner_id, provider, payer_email, payer_name, amount_minor, currency, cycle, cancel_token)
     VALUES (?,?,?,?,?,?,?,?,?,?)`
  ).bind(row.id, row.item_id, row.owner_id, provider, row.payer_email, row.payer_name, row.amount_minor, row.currency, row.cycle, row.cancel_token).run();
  return { row, item };
}

function subReceipt(env, row, item, business, extra = {}) {
  return {
    id: row.id, amount: toMajor(row.amount_minor, row.currency), currency: row.currency,
    description: `${item.name} (${row.cycle.toLowerCase()})`, business, method: row.provider === 'paypal' ? 'PayPal' : 'Card',
    created_at: nowIso(), ...extra,
  };
}

async function setStatus(env, row, status) {
  if (row.status === status) return;
  const now = nowIso();
  await env.DB.prepare(
    `UPDATE subscriptions SET status = ?,
       activated_at = CASE WHEN ? = 'active' AND activated_at IS NULL THEN ? ELSE activated_at END,
       cancelled_at = CASE WHEN ? = 'cancelled' THEN ? ELSE cancelled_at END
     WHERE id = ?`
  ).bind(status, status, now, status, now, row.id).run();
  row.status = status;
}

// ═════════════ Stripe Billing ═════════════
async function ensureStripeProduct(env, item) {
  if (item.stripe_product_id) return item.stripe_product_id;
  const r = await stripe(env, '/v1/products', {
    method: 'POST', idempotencyKey: `prod-${item.id}`,
    form: { name: String(item.name).slice(0, 200), 'metadata[item_id]': item.id },
  });
  if (!r.ok) { console.error('Stripe product failed', JSON.stringify(r.data?.error)); throw new HttpError(502, 'Could not set up the subscription'); }
  await env.DB.prepare('UPDATE items SET stripe_product_id = ? WHERE id = ?').bind(r.data.id, item.id).run();
  return r.data.id;
}

export async function stripeSubscribe(env, request) {
  const { row, item } = await startRow(env, request, 'stripe');
  const product = await ensureStripeProduct(env, item);
  const cust = await stripe(env, '/v1/customers', {
    method: 'POST', idempotencyKey: `cus-${row.id}`,
    form: { email: row.payer_email, ...(row.payer_name ? { name: row.payer_name } : {}), 'metadata[sub_id]': row.id },
  });
  if (!cust.ok) throw new HttpError(502, 'Could not start the subscription');
  const [interval, count] = cycleOf(row.cycle).stripe;
  const sub = await stripe(env, '/v1/subscriptions', {
    method: 'POST', idempotencyKey: `sub-${row.id}`,
    form: {
      customer: cust.data.id,
      'items[0][price_data][currency]': row.currency.toLowerCase(),
      'items[0][price_data][product]': product,
      'items[0][price_data][unit_amount]': String(row.amount_minor),
      'items[0][price_data][recurring][interval]': interval,
      'items[0][price_data][recurring][interval_count]': String(count),
      payment_behavior: 'default_incomplete',
      'payment_settings[save_default_payment_method]': 'on_subscription',
      'payment_settings[payment_method_types][]': 'card',
      'metadata[sub_id]': row.id, 'metadata[item_id]': item.id,
      'expand[]': 'latest_invoice.payment_intent',
    },
  });
  const secret = sub.data?.latest_invoice?.payment_intent?.client_secret;
  if (!sub.ok || !secret) { console.error('Stripe subscription failed', JSON.stringify(sub.data?.error)); throw new HttpError(502, 'Could not start the subscription'); }
  await env.DB.prepare('UPDATE subscriptions SET provider_sub_id = ?, stripe_customer_id = ? WHERE id = ?').bind(sub.data.id, cust.data.id, row.id).run();
  return json({ client_secret: secret, subscription_id: sub.data.id });
}

async function recordStripeInvoice(env, ctx, row, inv) {
  if (!inv || inv.status !== 'paid' || !inv.amount_paid) return null;
  const piId = typeof inv.payment_intent === 'string' ? inv.payment_intent : inv.payment_intent?.id;
  const txn = await recordPayment(env, ctx, orderFor(row), {
    provider: 'stripe', providerRef: piId || inv.id, grossMinor: inv.amount_paid, currency: String(inv.currency).toUpperCase(),
    payerName: row.payer_name, payerEmail: row.payer_email, subscriptionId: row.id, cancelUrl: cancelUrl(env, row),
  });
  await setStatus(env, row, 'active');
  return txn;
}

// After Stripe.js confirms the first payment, the Worker checks the first invoice with Stripe and records it
export async function stripeSubscribeConfirm(env, request, ctx) {
  const b = await readJson(request);
  if (typeof b.subscription_id !== 'string' || !/^sub_[A-Za-z0-9]+$/.test(b.subscription_id)) throw bad('Invalid subscription');
  const row = await env.DB.prepare("SELECT * FROM subscriptions WHERE provider = 'stripe' AND provider_sub_id = ?").bind(b.subscription_id).first();
  if (!row) throw notFound('Subscription not found');
  const r = await stripe(env, `/v1/subscriptions/${b.subscription_id}?expand[]=latest_invoice`);
  if (!r.ok || r.data.metadata?.sub_id !== row.id) throw notFound('Subscription not found');
  const txn = await recordStripeInvoice(env, ctx, row, r.data.latest_invoice);
  if (!txn) throw new HttpError(402, 'The first payment has not gone through yet.', 'not_paid');
  return json({ receipt: { ...(await receiptView(env, txn)), subscription: true } });
}

const STRIPE_STATUS = { active: 'active', trialing: 'active', past_due: 'past_due', unpaid: 'past_due', canceled: 'cancelled', incomplete_expired: 'cancelled' };

export async function stripeSubscriptionEvent(env, ctx, event) {
  const obj = event.data?.object || {};
  if (event.type === 'invoice.paid' || event.type === 'invoice.payment_failed') {
    // Re-read the invoice with our pinned API version so the fields are always where we expect
    const r = await stripe(env, `/v1/invoices/${obj.id}`);
    const inv = r.ok ? r.data : null;
    const subId = inv?.subscription;
    const row = subId && await env.DB.prepare("SELECT * FROM subscriptions WHERE provider = 'stripe' AND provider_sub_id = ?").bind(subId).first();
    if (!row) return true;
    if (event.type === 'invoice.paid') await recordStripeInvoice(env, ctx, row, inv).catch(e => { if (!(e instanceof HttpError)) throw e; });
    else if (row.status === 'active') await setStatus(env, row, 'past_due');
    return true;
  }
  if (event.type === 'customer.subscription.deleted' || event.type === 'customer.subscription.updated') {
    const row = await env.DB.prepare("SELECT * FROM subscriptions WHERE provider = 'stripe' AND provider_sub_id = ?").bind(obj.id).first();
    const st = event.type === 'customer.subscription.deleted' ? 'cancelled' : STRIPE_STATUS[obj.status];
    if (row && st && !(row.status === 'pending' && st === 'past_due')) await setStatus(env, row, st);
    return true;
  }
  return false;
}

// ═════════════ PayPal Subscriptions ═════════════
async function ensurePayPalPlan(env, item) {
  if (item.paypal_plan_id) return item.paypal_plan_id;
  let productId = item.paypal_product_id;
  if (!productId) {
    const p = await pp(env, '/v1/catalogs/products', {
      method: 'POST', requestId: `prod-${item.id}`,
      body: { name: String(item.name).slice(0, 127), type: 'SERVICE', category: 'SOFTWARE' },
    });
    if (!p.ok) { console.error('PayPal product failed', JSON.stringify(p.data)); throw new HttpError(502, 'Could not set up the subscription'); }
    productId = p.data.id;
    await env.DB.prepare('UPDATE items SET paypal_product_id = ? WHERE id = ?').bind(productId, item.id).run();
  }
  const [unit, count] = cycleOf(item.cycle).paypal;
  const plan = await pp(env, '/v1/billing/plans', {
    method: 'POST', requestId: `plan-${item.id}`,
    body: {
      product_id: productId, name: String(item.name).slice(0, 127), status: 'ACTIVE',
      billing_cycles: [{
        frequency: { interval_unit: unit, interval_count: count }, tenure_type: 'REGULAR', sequence: 1, total_cycles: 0,
        pricing_scheme: { fixed_price: { value: majorString(item.amount_minor, item.currency), currency_code: item.currency } },
      }],
      payment_preferences: { auto_bill_outstanding: true, payment_failure_threshold: 3 },
    },
  });
  if (!plan.ok) { console.error('PayPal plan failed', JSON.stringify(plan.data)); throw new HttpError(502, 'Could not set up the subscription'); }
  await env.DB.prepare('UPDATE items SET paypal_plan_id = ? WHERE id = ?').bind(plan.data.id, item.id).run();
  return plan.data.id;
}

// Step 1: the browser gets the plan and our subscription id, then PayPal's button creates the subscription
export async function paypalSubscribeStart(env, request) {
  const { row, item } = await startRow(env, request, 'paypal');
  const planId = await ensurePayPalPlan(env, item);
  return json({ plan_id: planId, custom_id: row.id, email: row.payer_email });
}

// Records every completed charge PayPal lists for this subscription (safe to repeat)
async function syncPayPalPayments(env, ctx, row) {
  if (!row.provider_sub_id) return [];
  const start = new Date(new Date(row.created_at).getTime() - 86400000).toISOString();
  const end = new Date(Date.now() + 86400000).toISOString();
  const r = await pp(env, `/v1/billing/subscriptions/${encodeURIComponent(row.provider_sub_id)}/transactions?start_time=${start}&end_time=${end}`);
  if (!r.ok) return [];
  const out = [];
  for (const t of r.data?.transactions || []) {
    if (t.status !== 'COMPLETED') continue;
    const gross = t.amount_with_breakdown?.gross_amount;
    if (!gross) continue;
    const txn = await recordPayment(env, ctx, orderFor(row), {
      provider: 'paypal', providerRef: t.id, grossMinor: toMinor(gross.value, gross.currency_code), currency: gross.currency_code,
      payerName: row.payer_name || [t.payer_name?.given_name, t.payer_name?.surname].filter(Boolean).join(' '),
      payerEmail: row.payer_email, subscriptionId: row.id, cancelUrl: cancelUrl(env, row),
    }).catch(e => { if (e instanceof HttpError) return null; throw e; });
    if (txn) out.push(txn);
  }
  return out;
}

const PAYPAL_STATUS = { ACTIVE: 'active', APPROVED: 'active', SUSPENDED: 'past_due', CANCELLED: 'cancelled', EXPIRED: 'cancelled' };

// Step 2: after the payer approves, the Worker checks the subscription with PayPal
export async function paypalSubscribeActivate(env, request, ctx) {
  const b = await readJson(request);
  if (typeof b.subscription_id !== 'string' || !/^I-[A-Z0-9]+$/.test(b.subscription_id)) throw bad('Invalid subscription');
  const r = await pp(env, `/v1/billing/subscriptions/${encodeURIComponent(b.subscription_id)}`);
  if (!r.ok) throw notFound('Subscription not found');
  const row = await env.DB.prepare("SELECT * FROM subscriptions WHERE id = ? AND provider = 'paypal'").bind(r.data.custom_id || '').first();
  if (!row) throw notFound('Subscription not found');
  const item = await env.DB.prepare('SELECT i.*, u.business_name, u.full_name FROM items i JOIN users u ON u.id = i.user_id WHERE i.id = ?').bind(row.item_id).first();
  if (r.data.plan_id !== item.paypal_plan_id) throw new HttpError(409, 'Subscription does not match this plan.');
  if (row.provider_sub_id && row.provider_sub_id !== b.subscription_id) throw new HttpError(409, 'Subscription already linked.');
  const st = PAYPAL_STATUS[r.data.status];
  if (st !== 'active') throw new HttpError(402, 'PayPal has not activated this subscription.', 'not_active');
  await env.DB.prepare('UPDATE subscriptions SET provider_sub_id = ? WHERE id = ?').bind(b.subscription_id, row.id).run();
  row.provider_sub_id = b.subscription_id;
  await setStatus(env, row, 'active');
  const paid = await syncPayPalPayments(env, ctx, row);
  const business = item.business_name || item.full_name || 'VyCheckout';
  if (paid.length) return json({ receipt: { ...(await receiptView(env, paid[0])), subscription: true } });
  return json({ receipt: subReceipt(env, row, item, business, { subscription: true, pending: true }) });
}

export async function paypalSubscriptionEvent(env, ctx, event) {
  const res = event.resource || {};
  const t = event.event_type;
  if (t === 'PAYMENT.SALE.COMPLETED') {
    // Sale of a subscription: billing_agreement_id holds the subscription id (I-…)
    const row = res.billing_agreement_id && await env.DB.prepare("SELECT * FROM subscriptions WHERE provider = 'paypal' AND provider_sub_id = ?").bind(res.billing_agreement_id).first();
    if (row) await syncPayPalPayments(env, ctx, row);
    return true;
  }
  if (t === 'PAYMENT.SALE.REFUNDED' || t === 'PAYMENT.SALE.REVERSED') {
    const saleId = res.sale_id || res.id;
    const txn = saleId && await env.DB.prepare("SELECT * FROM transactions WHERE provider = 'paypal' AND provider_ref = ?").bind(saleId).first();
    if (txn) {
      const amt = res.amount?.total ? toMinor(res.amount.total, res.amount.currency || txn.currency) : txn.gross_minor;
      await applyRefund(env, ctx, txn, 'paypal', `${t}-${res.id}`, amt);
    }
    return true;
  }
  if (t.startsWith('BILLING.SUBSCRIPTION.')) {
    const row = await env.DB.prepare("SELECT * FROM subscriptions WHERE provider = 'paypal' AND (provider_sub_id = ? OR id = ?)").bind(res.id || '', res.custom_id || '').first();
    if (!row) return true;
    if (t === 'BILLING.SUBSCRIPTION.PAYMENT.FAILED') await setStatus(env, row, 'past_due');
    else if (PAYPAL_STATUS[res.status]) {
      if (!row.provider_sub_id && res.id && res.custom_id === row.id) {
        await env.DB.prepare('UPDATE subscriptions SET provider_sub_id = ? WHERE id = ?').bind(res.id, row.id).run();
        row.provider_sub_id = res.id;
      }
      await setStatus(env, row, PAYPAL_STATUS[res.status]);
      if (row.status === 'active') await syncPayPalPayments(env, ctx, row);
    }
    return true;
  }
  return false;
}

// ═════════════ Cancelling ═════════════
export async function cancelAtProvider(env, row, reason) {
  if (row.status === 'cancelled') return;
  if (row.provider_sub_id) {
    const r = row.provider === 'stripe'
      ? await stripe(env, `/v1/subscriptions/${row.provider_sub_id}`, { method: 'DELETE' })
      : await pp(env, `/v1/billing/subscriptions/${encodeURIComponent(row.provider_sub_id)}/cancel`, { method: 'POST', body: { reason: String(reason).slice(0, 120) } });
    // 404/422 usually means it is already cancelled at the provider
    if (!r.ok && ![404, 422].includes(r.status)) {
      console.error('Cancel failed', row.provider, r.status, JSON.stringify(r.data));
      throw new HttpError(502, 'Could not cancel with the payment provider. Please try again.');
    }
  }
  await setStatus(env, row, 'cancelled');
}

// Merchant cancels one of their subscribers
export async function merchantCancel(env, request, id) {
  const u = await requireUser(env, request);
  const row = await env.DB.prepare('SELECT * FROM subscriptions WHERE id = ? AND owner_id = ?').bind(id, u.id).first();
  if (!row) throw notFound('Subscription not found');
  await cancelAtProvider(env, row, 'Cancelled by the merchant');
  await audit(env, u.id, 'subscription_cancel', id);
  return json({ ok: true });
}

// Subscriber cancels from the link in their receipt email
async function rowByToken(env, token) {
  if (typeof token !== 'string' || token.length < 20 || token.length > 64) throw notFound('This cancel link is not valid.');
  const row = await env.DB.prepare(
    `SELECT s.*, i.name AS item_name, u.business_name, u.full_name FROM subscriptions s
     JOIN items i ON i.id = s.item_id JOIN users u ON u.id = s.owner_id WHERE s.cancel_token = ?`
  ).bind(token).first();
  if (!row) throw notFound('This cancel link is not valid.');
  return row;
}
export async function publicLookup(env, request) {
  const row = await rowByToken(env, (await readJson(request)).token);
  return json({
    item: row.item_name, business: row.business_name || row.full_name, amount: toMajor(row.amount_minor, row.currency),
    currency: row.currency, cycle: row.cycle, status: row.status, email: row.payer_email.replace(/^(.).*(@.*)$/, '$1•••$2'),
  });
}
export async function publicCancel(env, request) {
  const row = await rowByToken(env, (await readJson(request)).token);
  await cancelAtProvider(env, row, 'Cancelled by the subscriber');
  return json({ ok: true });
}

// Subscribers of a merchant, for the dashboard
export async function listForOwner(env, ownerId) {
  const { results } = await env.DB.prepare(
    `SELECT s.id, s.item_id, s.provider, s.payer_email, s.payer_name, s.amount_minor, s.currency, s.cycle, s.status, s.created_at, s.activated_at, s.cancelled_at
     FROM subscriptions s WHERE s.owner_id = ? AND s.status != 'pending' ORDER BY s.created_at DESC LIMIT 500`
  ).bind(ownerId).all();
  return results.map(s => ({ ...s, amount: toMajor(s.amount_minor, s.currency), amount_minor: undefined, method: s.provider === 'paypal' ? 'PayPal' : 'Card' }));
}

// Cron: forget subscription attempts that were never completed
export async function cleanupPending(env) {
  await env.DB.prepare("DELETE FROM subscriptions WHERE status = 'pending' AND created_at < ?").bind(new Date(Date.now() - 2 * 86400000).toISOString()).run();
}
