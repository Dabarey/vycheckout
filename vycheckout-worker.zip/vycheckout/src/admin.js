// Admin endpoints. Every route checks the admin flag on the server and writes to audit_log.
import { bad, notFound, json, readJson, nowIso, newId, toMinor, toMajor, cleanCurrency, str, audit } from './lib.js';
import { requireAdmin, isAdmin } from './auth.js';
import { holdDaysFor } from './lib.js';
import { sendEmail, formatMoney } from './email.js';

const sums = rows => Object.fromEntries(rows.filter(r => r.total).map(r => [r.currency, toMajor(r.total, r.currency)]));

export async function listWithdrawals(env, request) {
  await requireAdmin(env, request);
  const status = new URL(request.url).searchParams.get('status') || 'pending';
  const where = ['pending', 'approved', 'completed', 'rejected'].includes(status) ? 'WHERE w.status = ?' : '';
  const stmt = env.DB.prepare(
    `SELECT w.*, u.full_name AS user_name, u.email AS user_email FROM withdrawals w JOIN users u ON u.id = w.user_id
     ${where} ORDER BY w.created_at DESC LIMIT 500`
  );
  const { results } = await (where ? stmt.bind(status) : stmt).all();
  return json({
    withdrawals: results.map(w => ({
      id: w.id, user_name: w.user_name, user_email: w.user_email, currency: w.currency,
      amount: toMajor(w.amount_minor, w.currency), method: w.method, destination: w.destination, country: w.country,
      bank_details: w.bank_details ? JSON.parse(w.bank_details) : null, notes: w.notes, status: w.status,
      admin_note: w.admin_note, created_at: w.created_at,
      payout_status: w.payout_status, payout_error: w.payout_error,
    })),
  });
}

// pending → approved | rejected; approved → completed | rejected. Rejecting returns the money to the balance.
const ALLOWED_FROM = { approved: ['pending'], rejected: ['pending', 'approved'], completed: ['approved'] };

export async function updateWithdrawal(env, request, id, ctx) {
  const admin = await requireAdmin(env, request);
  const b = await readJson(request);
  const from = ALLOWED_FROM[b.status];
  if (!from) throw bad('Invalid status');
  const note = str(b.note, { max: 300, field: 'Note' }) || null;
  // Once a PayPal payout is on its way (or done), the request can't be rejected: the money has left
  const r = await env.DB.prepare(
    `UPDATE withdrawals SET status = ?, admin_note = COALESCE(?, admin_note), updated_at = ?
     WHERE id = ? AND status IN (${from.map(() => '?').join(',')})
       AND (? != 'rejected' OR payout_status IS NULL OR payout_status IN ('FAILED','RETURNED','BLOCKED','REFUNDED','REVERSED','DENIED','CANCELED'))`
  ).bind(b.status, note, nowIso(), id, ...from, b.status).run();
  if (!r.meta.changes) throw bad('This request was already handled, has a PayPal payout in progress, or does not exist. Refresh the list.');
  // Let the merchant know what happened to their request
  const w = await env.DB.prepare('SELECT w.*, u.email FROM withdrawals w JOIN users u ON u.id = w.user_id WHERE w.id = ?').bind(id).first();
  if (w?.email) {
    const what = { approved: 'was approved and will be sent soon', rejected: 'was rejected and the money is back in your balance', completed: 'has been paid' }[b.status];
    ctx.waitUntil(sendEmail(env, {
      to: w.email, subject: `Your withdrawal ${what.split(' ').slice(0, 2).join(' ')}`,
      text: `Your withdrawal of ${formatMoney(w.amount_minor, w.currency)} ${what}.${note ? `\nNote: ${note}` : ''}`,
    }));
  }
  await audit(env, admin.id, `withdrawal_${b.status}`, id, { note });
  return json({ ok: true });
}

export async function listUsers(env, request) {
  await requireAdmin(env, request);
  const [users, bals, held] = await env.DB.batch([
    env.DB.prepare('SELECT id, email, email_verified, full_name, business_name, ref_code, referrer_id, is_admin, suspended, hold_days, created_at FROM users WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 1000'),
    env.DB.prepare(`SELECT user_id, currency, SUM(amt) AS total FROM (
        SELECT user_id, currency, amount_minor AS amt FROM ledger WHERE available_at IS NULL OR available_at <= ?1
        UNION ALL SELECT user_id, currency, -amount_minor FROM withdrawals WHERE status != 'rejected'
      ) GROUP BY user_id, currency`).bind(nowIso()),
    env.DB.prepare(`SELECT user_id, currency, SUM(amount_minor) AS total FROM ledger WHERE available_at > ?1 GROUP BY user_id, currency`).bind(nowIso()),
  ]);
  const heldBy = {};
  for (const r of held.results) (heldBy[r.user_id] ||= []).push(r);
  const byUser = {};
  for (const r of bals.results) (byUser[r.user_id] ||= []).push(r);
  return json({
    users: users.results.map(u => ({
      ...u, email_verified: !!u.email_verified, suspended: !!u.suspended, is_admin: isAdmin(env, u),
      balances: sums(byUser[u.id] || []), held: sums(heldBy[u.id] || []), hold_days: holdDaysFor(env, u), hold_override: u.hold_days,
    })),
  });
}

export async function setSuspended(env, request, id) {
  const admin = await requireAdmin(env, request);
  const b = await readJson(request);
  if (id === admin.id) throw bad("You can't suspend yourself");
  const on = !!b.suspended;
  const stmts = [env.DB.prepare('UPDATE users SET suspended = ? WHERE id = ?').bind(on ? 1 : 0, id)];
  if (on) stmts.push(env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(id));
  await env.DB.batch(stmts);
  await audit(env, admin.id, on ? 'user_suspend' : 'user_unsuspend', id);
  return json({ ok: true });
}

// Per-merchant payment hold: a number of days, or null to go back to the default rules
export async function setHold(env, request, id) {
  const admin = await requireAdmin(env, request);
  const b = await readJson(request);
  let days = null;
  if (b.days !== null && b.days !== '' && b.days !== undefined) {
    days = Number(b.days);
    if (!Number.isInteger(days) || days < 0 || days > 180) throw bad('Hold must be a whole number of days between 0 and 180');
  }
  const r = await env.DB.prepare('UPDATE users SET hold_days = ? WHERE id = ? AND deleted_at IS NULL').bind(days, id).run();
  if (!r.meta.changes) throw notFound('User not found');
  await audit(env, admin.id, 'hold_change', id, { days });
  return json({ ok: true });
}

// Adds a signed amount to the user's balance as a ledger entry (never overwritten by later recalculation)
export async function adjustBalance(env, request, id) {
  const admin = await requireAdmin(env, request);
  const b = await readJson(request);
  const currency = cleanCurrency(b.currency);
  const amount = toMinor(b.amount, currency);
  if (!amount) throw bad('Enter a non-zero amount');
  const note = str(b.note, { max: 300, required: true, field: 'Reason' });
  const u = await env.DB.prepare('SELECT id FROM users WHERE id = ? AND deleted_at IS NULL').bind(id).first();
  if (!u) throw notFound('User not found');
  await env.DB.prepare("INSERT INTO ledger (id, user_id, currency, amount_minor, kind, note, created_by) VALUES (?,?,?,?,'adjustment',?,?)")
    .bind(newId(), id, currency, amount, note, admin.id).run();
  await audit(env, admin.id, 'balance_adjust', id, { currency, amount: toMajor(amount, currency), note });
  return json({ ok: true });
}

// Payment records are kept for accounting, so "delete" closes the account: personal data is wiped,
// the user is signed out and their links stop working.
export async function deleteUser(env, request, id) {
  const admin = await requireAdmin(env, request);
  if (id === admin.id) throw bad("You can't delete yourself");
  const now = nowIso();
  await env.DB.batch([
    env.DB.prepare(`UPDATE users SET deleted_at = ?, suspended = 1, email = 'deleted+' || id || '@deleted.invalid', password_hash = NULL,
                    google_sub = NULL, full_name = 'Deleted user', business_name = '', bio = NULL, avatar = NULL,
                    webhook_url = NULL, webhook_secret = NULL WHERE id = ? AND deleted_at IS NULL`).bind(now, id),
    env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(id),
    env.DB.prepare('UPDATE api_keys SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL').bind(now, id),
    env.DB.prepare('UPDATE items SET deleted_at = ? WHERE user_id = ? AND deleted_at IS NULL').bind(now, id),
    env.DB.prepare('DELETE FROM follows WHERE follower_id = ? OR following_id = ?').bind(id, id),
  ]);
  await audit(env, admin.id, 'user_delete', id);
  return json({ ok: true });
}

export async function listTransactions(env, request) {
  await requireAdmin(env, request);
  const { results } = await env.DB.prepare(
    `SELECT t.*, u.full_name, u.email FROM transactions t JOIN users u ON u.id = t.owner_id ORDER BY t.created_at DESC LIMIT 300`
  ).all();
  return json({
    transactions: results.map(t => ({
      id: t.id, created_at: t.created_at, user: t.full_name || t.email, description: t.description, currency: t.currency,
      gross_amount: toMajor(t.gross_minor, t.currency), fee_amount: toMajor(t.fee_minor, t.currency),
      net_amount: toMajor(t.net_minor, t.currency), referral_amount: toMajor(t.referral_minor, t.currency),
      payment_method: t.provider === 'paypal' ? 'PayPal' : 'Card', status: t.status,
    })),
  });
}

export async function stats(env, request) {
  await requireAdmin(env, request);
  const since = new Date(); since.setUTCMonth(since.getUTCMonth() - 5, 1); since.setUTCHours(0, 0, 0, 0);
  const q = sql => env.DB.prepare(sql);
  const [vol, wds, users, monthly, top] = await env.DB.batch([
    q(`SELECT currency, COUNT(*) AS n, SUM(gross_minor) AS gross, SUM(fee_minor) AS fees, SUM(referral_minor) AS refs,
         COUNT(DISTINCT owner_id) AS sellers FROM transactions GROUP BY currency`),
    q(`SELECT currency, status, SUM(amount_minor) AS total FROM withdrawals GROUP BY currency, status`),
    q(`SELECT COUNT(*) AS total, SUM(referrer_id IS NOT NULL) AS referred,
         (SELECT COUNT(DISTINCT user_id) FROM api_keys WHERE revoked_at IS NULL) AS api_users
       FROM users WHERE deleted_at IS NULL`),
    env.DB.prepare(`SELECT substr(created_at, 1, 7) AS month, currency, SUM(fee_minor) AS fees FROM transactions
       WHERE created_at >= ? GROUP BY month, currency ORDER BY month`).bind(since.toISOString()),
    q(`SELECT u.full_name, u.business_name, u.email, l.currency, SUM(l.amount_minor) AS earned FROM ledger l
       JOIN users u ON u.id = l.user_id WHERE l.kind IN ('sale','refund') GROUP BY l.user_id, l.currency ORDER BY earned DESC LIMIT 5`),
  ]);
  const by = (rows, f) => Object.fromEntries(rows.map(r => [r.currency, toMajor(r[f] || 0, r.currency)]));
  const wdBy = status => Object.fromEntries(wds.results.filter(w => w.status === status).map(w => [w.currency, toMajor(w.total, w.currency)]));
  return json({
    volume: by(vol.results, 'gross'), fees: by(vol.results, 'fees'), referral_paid: by(vol.results, 'refs'),
    txn_count: vol.results.reduce((a, r) => a + r.n, 0),
    active_sellers: vol.results.reduce((a, r) => Math.max(a, r.sellers), 0),
    pending_payouts: wdBy('pending'), approved_payouts: wdBy('approved'), paid_out: wdBy('completed'),
    users: users.results[0].total, referred_users: users.results[0].referred || 0, api_users: users.results[0].api_users || 0,
    monthly_fees: monthly.results.map(m => ({ month: m.month, currency: m.currency, fees: toMajor(m.fees, m.currency) })),
    top_earners: top.results.map(t => ({ name: t.business_name || t.full_name || t.email, currency: t.currency, earned: toMajor(t.earned, t.currency) })),
  });
}
