// Signed webhooks to merchants' own servers.
// Header: VyCheckout-Signature: t=<unix seconds>,v1=<hex HMAC-SHA256 of "<t>.<raw body>" using the merchant's secret>
import { newId, hmacHex } from './lib.js';

const MAX_ATTEMPTS = 6;
const BACKOFF_MIN = [1, 5, 30, 120, 360, 720]; // minutes before attempt n+1

export async function enqueueWebhook(env, ctx, userId, event, data) {
  const u = await env.DB.prepare('SELECT webhook_url, webhook_secret FROM users WHERE id = ?').bind(userId).first();
  if (!u?.webhook_url || !u.webhook_secret) return;
  const id = newId();
  const payload = JSON.stringify({ id, type: event, created: Math.floor(Date.now() / 1000), data });
  await env.DB.prepare(
    'INSERT INTO webhook_deliveries (id, user_id, url, event, payload, next_attempt_at) VALUES (?,?,?,?,?,?)'
  ).bind(id, userId, u.webhook_url, event, payload, Date.now()).run();
  ctx.waitUntil(attempt(env, { id, user_id: userId, url: u.webhook_url, payload, attempts: 0 }));
}

async function attempt(env, row) {
  const u = await env.DB.prepare('SELECT webhook_secret FROM users WHERE id = ?').bind(row.user_id).first();
  if (!u?.webhook_secret) {
    await env.DB.prepare("UPDATE webhook_deliveries SET status = 'failed', last_error = 'webhook removed' WHERE id = ?").bind(row.id).run();
    return;
  }
  const t = Math.floor(Date.now() / 1000);
  const sig = await hmacHex(u.webhook_secret, `${t}.${row.payload}`);
  let error = null;
  try {
    const res = await fetch(row.url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'User-Agent': 'VyCheckout-Webhooks/1.0', 'VyCheckout-Signature': `t=${t},v1=${sig}` },
      body: row.payload,
      redirect: 'manual',
      signal: AbortSignal.timeout(10000),
    });
    if (res.status < 200 || res.status >= 300) error = `HTTP ${res.status}`;
  } catch (e) {
    error = String(e?.message || e).slice(0, 200);
  }
  const attempts = row.attempts + 1;
  if (!error) {
    await env.DB.prepare("UPDATE webhook_deliveries SET status = 'delivered', attempts = ?, last_error = NULL WHERE id = ?").bind(attempts, row.id).run();
  } else if (attempts >= MAX_ATTEMPTS) {
    await env.DB.prepare("UPDATE webhook_deliveries SET status = 'failed', attempts = ?, last_error = ? WHERE id = ?").bind(attempts, error, row.id).run();
  } else {
    const next = Date.now() + BACKOFF_MIN[attempts - 1] * 60000;
    await env.DB.prepare('UPDATE webhook_deliveries SET attempts = ?, last_error = ?, next_attempt_at = ? WHERE id = ?').bind(attempts, error, next, row.id).run();
  }
}

// Called by the cron trigger
export async function retryDueWebhooks(env) {
  const { results } = await env.DB.prepare(
    // First attempts normally run right away; pick them up here only if that never happened (2+ min old)
    `SELECT * FROM webhook_deliveries WHERE status = 'pending'
       AND next_attempt_at <= CASE WHEN attempts = 0 THEN ?2 ELSE ?1 END
     ORDER BY next_attempt_at LIMIT 50`
  ).bind(Date.now(), Date.now() - 120000).all();
  await Promise.all(results.map(r => attempt(env, r)));
}
