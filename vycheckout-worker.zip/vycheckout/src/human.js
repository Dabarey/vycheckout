// Bot protection with Cloudflare Turnstile.
// The browser solves Turnstile once and posts the token to /api/human; the Worker checks it with Cloudflare and
// sets a short-lived signed cookie. Signup, login, password reset and starting a payment require that cookie.
// Without TURNSTILE_SECRET_KEY the check is off (handy for local development).
import { HttpError, json, readJson, hmacHex, safeEqual, rateLimit, clientIp } from './lib.js';

const COOKIE = 'vy_human';
const PASS_SECONDS = 30 * 60;

const enabled = env => !!(env.TURNSTILE_SECRET_KEY && env.TURNSTILE_SITE_KEY);
const signingKey = env => `human-pass:${env.TURNSTILE_SECRET_KEY}`;

function readCookie(request, name) {
  for (const part of (request.headers.get('Cookie') || '').split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return v.join('=');
  }
  return null;
}

export async function verifyHuman(env, request) {
  const b = await readJson(request);
  if (!enabled(env)) return json({ ok: true, expires_in: PASS_SECONDS });
  await rateLimit(env, `human:${clientIp(request)}`, 60, 600000);
  const token = typeof b.token === 'string' ? b.token.slice(0, 4096) : '';
  if (!token) throw new HttpError(400, 'Security check missing. Please try again.', 'human_check');
  const res = await fetch(env.TURNSTILE_VERIFY_URL || 'https://challenges.cloudflare.com/turnstile/v0/siteverify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ secret: env.TURNSTILE_SECRET_KEY, response: token, remoteip: clientIp(request) }),
  });
  const d = await res.json().catch(() => ({}));
  if (!d.success) throw new HttpError(403, 'Security check failed. Please try again.', 'human_check');
  const exp = Math.floor(Date.now() / 1000) + PASS_SECONDS;
  const sig = await hmacHex(signingKey(env), String(exp));
  return json({ ok: true, expires_in: PASS_SECONDS }, 200, {
    'Set-Cookie': `${COOKIE}=${exp}.${sig}; Path=/api; HttpOnly; Secure; SameSite=Lax; Max-Age=${PASS_SECONDS}`,
  });
}

export async function requireHuman(env, request) {
  if (!enabled(env)) return;
  const [exp, sig] = (readCookie(request, COOKIE) || '').split('.');
  const ok = exp && sig && parseInt(exp, 10) > Date.now() / 1000 && safeEqual(sig, await hmacHex(signingKey(env), exp));
  if (!ok) throw new HttpError(403, 'Please complete the security check.', 'human_check');
}
