// Account settings for the signed-in user.
import { bad, forbidden, json, readJson, nowIso, hashPassword, verifyPassword, emailOf, rateLimit, audit } from './lib.js';
import { requireUser, createSession, sendVerification, clearSessionCookie, selfView } from './auth.js';
import { sendEmail } from './email.js';
import { cancelAtProvider } from './subscriptions.js';

async function checkPassword(env, u, password) {
  if (!u.password_hash) throw bad('Your account uses Google sign-in. Use "Forgot password" on the sign-in page to set a password first.', 'no_password');
  await rateLimit(env, `pw-check:${u.id}`, 10, 900000);
  if (!(await verifyPassword(String(password || ''), u.password_hash))) throw bad('Your current password is wrong', 'bad_password');
}

export async function changePassword(env, request) {
  const u = await requireUser(env, request);
  const b = await readJson(request);
  if (u.password_hash) await checkPassword(env, u, b.current_password);
  const pw = String(b.new_password || '');
  if (pw.length < 8) throw bad('New password must be 8+ characters');
  if (pw.length > 200) throw bad('Password is too long');
  // Signs out every other device; this one gets a fresh session
  await env.DB.batch([
    env.DB.prepare('UPDATE users SET password_hash = ? WHERE id = ?').bind(await hashPassword(pw), u.id),
    env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(u.id),
  ]);
  await audit(env, u.id, 'password_change', u.id);
  if (u.email) await sendEmail(env, { to: u.email, subject: 'Your VyCheckout password was changed', text: 'Your password was just changed. If this wasn\'t you, reset your password now and contact support.' });
  return json({ ok: true }, 200, { 'Set-Cookie': await createSession(env, u.id) });
}

export async function changeEmail(env, request, ctx) {
  const u = await requireUser(env, request);
  const b = await readJson(request);
  await checkPassword(env, u, b.password);
  const email = emailOf(b.email);
  if (email === String(u.email).toLowerCase()) throw bad('That is already your email');
  const taken = await env.DB.prepare('SELECT 1 FROM users WHERE email = ?').bind(email).first();
  if (taken) throw bad('Another account already uses that email');
  // Google sign-in is tied to the old address, so unlink it; the new address must be confirmed again
  await env.DB.prepare('UPDATE users SET email = ?, email_verified = 0, google_sub = NULL WHERE id = ?').bind(email, u.id).run();
  await audit(env, u.id, 'email_change', u.id, { from: u.email, to: email });
  ctx.waitUntil(sendEmail(env, { to: u.email, subject: 'Your VyCheckout email was changed', text: `Your account email was changed to ${email}. If this wasn't you, contact support right away.` }));
  ctx.waitUntil(sendVerification(env, request, { id: u.id, email }));
  const fresh = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(u.id).first();
  return json({ user: selfView(env, fresh) });
}

export async function updateSettings(env, request) {
  const u = await requireUser(env, request);
  const b = await readJson(request);
  if ('notify_sales' in b) await env.DB.prepare('UPDATE users SET notify_sales = ? WHERE id = ?').bind(b.notify_sales ? 1 : 0, u.id).run();
  return json({ ok: true });
}

export async function logoutAll(env, request) {
  const u = await requireUser(env, request);
  await env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(u.id).run();
  return json({ ok: true }, 200, { 'Set-Cookie': clearSessionCookie() });
}

// Closes the account. Blocked while money is still owed to the user or payouts are open,
// so nobody deletes an account with funds in it by mistake.
export async function deleteAccount(env, request, ctx) {
  const u = await requireUser(env, request);
  const b = await readJson(request);
  if (u.password_hash) await checkPassword(env, u, b.password);
  else if (b.confirm !== 'DELETE') throw bad('Type DELETE to confirm');
  const [bal, open] = await env.DB.batch([
    env.DB.prepare(`SELECT currency, SUM(amt) AS b FROM (
        SELECT currency, amount_minor AS amt FROM ledger WHERE user_id = ?1
        UNION ALL SELECT currency, -amount_minor FROM withdrawals WHERE user_id = ?1 AND status != 'rejected'
      ) GROUP BY currency HAVING b > 0`).bind(u.id),
    env.DB.prepare("SELECT COUNT(*) AS n FROM withdrawals WHERE user_id = ? AND status IN ('pending','approved')").bind(u.id),
  ]);
  if (bal.results.length) throw forbidden('You still have money in your balance. Withdraw it first (pending money becomes available after the hold).');
  if (open.results[0].n) throw forbidden('You have a withdrawal in progress. Wait until it is paid, then delete your account.');

  // Stop billing everyone subscribed to this merchant's plans
  const { results: subs } = await env.DB.prepare("SELECT * FROM subscriptions WHERE owner_id = ? AND status IN ('active','past_due')").bind(u.id).all();
  for (const s of subs) await cancelAtProvider(env, s, 'Merchant closed their account').catch(e => console.error('cancel on delete', e));

  const now = nowIso();
  await env.DB.batch([
    env.DB.prepare(`UPDATE users SET deleted_at = ?, suspended = 1, email = 'deleted+' || id || '@deleted.invalid', password_hash = NULL,
                    google_sub = NULL, full_name = 'Deleted user', business_name = '', bio = NULL, avatar = NULL,
                    webhook_url = NULL, webhook_secret = NULL WHERE id = ?`).bind(now, u.id),
    env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(u.id),
    env.DB.prepare('UPDATE api_keys SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL').bind(now, u.id),
    env.DB.prepare('UPDATE items SET deleted_at = ? WHERE user_id = ? AND deleted_at IS NULL').bind(now, u.id),
    env.DB.prepare('DELETE FROM follows WHERE follower_id = ? OR following_id = ?').bind(u.id, u.id),
  ]);
  await audit(env, u.id, 'account_self_delete', u.id);
  return json({ ok: true }, 200, { 'Set-Cookie': clearSessionCookie() });
}
