// VyCheckout Worker: serves the site (static assets) and the /api backend.
import { HttpError, json } from './lib.js';
import * as auth from './auth.js';
import * as app from './app.js';
import * as pay from './payments.js';
import * as admin from './admin.js';
import { retryDueWebhooks } from './webhooks.js';

// State-changing requests from the browser must be same-origin and carry our custom header.
// A cross-site page can't add custom headers without a CORS preflight, which this Worker never approves.
function checkCsrf(request, env) {
  const origin = request.headers.get('Origin');
  const self = new URL(request.url).origin;
  const allowed = [self, env.APP_URL && env.APP_URL.replace(/\/$/, '')].filter(Boolean);
  if (origin && !allowed.includes(origin)) throw new HttpError(403, 'Cross-site request blocked', 'csrf');
  if (request.headers.get('X-Requested-With') !== 'VyCheckout') throw new HttpError(403, 'Missing request header', 'csrf');
}

async function route(request, env, ctx) {
  const url = new URL(request.url);
  const p = url.pathname;
  const m = request.method;

  // Provider webhooks: authenticated by signature, not cookies
  if (m === 'POST' && p === '/webhooks/paypal') return pay.paypalWebhook(env, request, ctx);
  if (m === 'POST' && p === '/webhooks/stripe') return pay.stripeWebhook(env, request, ctx);

  // Merchant API: authenticated by API key
  if (p.startsWith('/api/v1/')) return app.apiV1(env, request, p);

  // Google sign-in redirects (top-level GET navigations)
  if (m === 'GET' && p === '/api/auth/google/start') return auth.googleStart(env, request);
  if (m === 'GET' && p === '/api/auth/google/callback') return auth.googleCallback(env, request, ctx);
  if (m === 'GET' && p === '/api/auth/verify') return auth.verifyEmail(env, request);

  if (m !== 'GET' && m !== 'HEAD') checkCsrf(request, env);

  const seg = p.split('/').filter(Boolean); // ['api', ...]
  const id = seg[3];
  switch (`${m} ${p}`) {
    case 'GET /api/config': return app.publicConfig(env);
    case 'GET /api/me': return app.me(env, request);
    case 'PATCH /api/me': return app.updateProfile(env, request);
    case 'GET /api/dashboard': return app.dashboard(env, request);
    case 'GET /api/feed': return app.feed(env, request);

    case 'POST /api/auth/signup': return auth.signup(env, request, ctx);
    case 'POST /api/auth/login': return auth.login(env, request);
    case 'POST /api/auth/logout': return auth.logout(env, request);
    case 'POST /api/auth/forgot': return auth.forgot(env, request, ctx);
    case 'POST /api/auth/reset': return auth.resetPassword(env, request);
    case 'POST /api/auth/resend-verification': return auth.resendVerification(env, request, ctx);

    case 'POST /api/items': return app.createItem(env, request);
    case 'POST /api/withdrawals': return app.requestWithdrawal(env, request, ctx);
    case 'POST /api/api-key': return app.createApiKey(env, request);
    case 'DELETE /api/api-key': return app.revokeApiKey(env, request);
    case 'PUT /api/webhook': return app.setWebhook(env, request);

    case 'POST /api/pay/paypal/order': return pay.paypalCreateOrder(env, request);
    case 'POST /api/pay/paypal/capture': return pay.paypalCapture(env, request, ctx);
    case 'POST /api/pay/stripe/intent': return pay.stripeCreateIntent(env, request);
    case 'POST /api/pay/stripe/confirm': return pay.stripeConfirm(env, request, ctx);

    case 'GET /api/admin/withdrawals': return admin.listWithdrawals(env, request);
    case 'GET /api/admin/users': return admin.listUsers(env, request);
    case 'GET /api/admin/transactions': return admin.listTransactions(env, request);
    case 'GET /api/admin/stats': return admin.stats(env, request);
  }

  // Routes with an id: /api/<resource>/<id>[/<action>]
  const res = seg[1], rid = seg[2], action = seg[3];
  if (seg[0] === 'api' && rid) {
    if (res === 'items' && m === 'DELETE' && !action) return app.deleteItem(env, request, rid);
    if (res === 'follows' && !action && (m === 'POST' || m === 'DELETE')) return app.follow(env, request, rid, m === 'POST');
    if (res === 'public' && m === 'GET' && rid === 'items' && id) return app.publicItem(env, request, id);
    if (res === 'public' && m === 'GET' && rid === 'profiles' && id) return app.publicProfile(env, request, id);
    if (res === 'admin' && seg[2] === 'withdrawals' && seg[3] && m === 'POST') return admin.updateWithdrawal(env, request, seg[3]);
    if (res === 'admin' && seg[2] === 'users' && seg[3]) {
      if (m === 'POST' && seg[4] === 'suspend') return admin.setSuspended(env, request, seg[3]);
      if (m === 'POST' && seg[4] === 'adjust') return admin.adjustBalance(env, request, seg[3]);
      if (m === 'DELETE' && !seg[4]) return admin.deleteUser(env, request, seg[3]);
    }
  }
  return json({ error: 'Not found' }, 404);
}

export default {
  async fetch(request, env, ctx) {
    const p = new URL(request.url).pathname;
    if (!p.startsWith('/api/') && !p.startsWith('/webhooks/')) return env.ASSETS.fetch(request);
    try {
      return await route(request, env, ctx);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message, code: e.code }, e.status);
      console.error('Unhandled error', p, e?.stack || e);
      return json({ error: 'Something went wrong. Please try again.' }, 500);
    }
  },

  // Cron: retry merchant webhooks and tidy expired rows
  async scheduled(event, env, ctx) {
    ctx.waitUntil((async () => {
      await retryDueWebhooks(env);
      const now = Date.now();
      await env.DB.batch([
        env.DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(now),
        env.DB.prepare('DELETE FROM auth_tokens WHERE expires_at < ?').bind(now - 86400000),
        env.DB.prepare('DELETE FROM rate_limits WHERE window_start < ?').bind(now - 86400000),
        env.DB.prepare("DELETE FROM orders WHERE status = 'created' AND created_at < ?").bind(new Date(now - 30 * 86400000).toISOString()),
      ]);
    })());
  },
};
