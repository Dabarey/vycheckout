// VyCheckout Worker: serves the site (static assets) and the /api backend.
import { HttpError, json } from './lib.js';
import * as auth from './auth.js';
import * as app from './app.js';
import * as pay from './payments.js';
import * as subs from './subscriptions.js';
import * as payouts from './payouts.js';
import * as account from './account.js';
import * as admin from './admin.js';
import { verifyHuman } from './human.js';
import { retryDueWebhooks } from './webhooks.js';
import { dailyDigest } from './alerts.js';

// State-changing requests from the browser must be same-origin and carry our custom header.
// A cross-site page can't add custom headers without a CORS preflight, which this Worker never approves.
function checkCsrf(request, env) {
  const origin = request.headers.get('Origin');
  const self = new URL(request.url).origin;
  const allowed = [self, env.APP_URL && env.APP_URL.replace(/\/$/, '')].filter(Boolean);
  if (origin && !allowed.includes(origin)) throw new HttpError(403, 'Cross-site request blocked', 'csrf');
  if (request.headers.get('X-Requested-With') !== 'VyCheckout') throw new HttpError(403, 'Missing request header', 'csrf');
}

// ── Provider webhooks (authenticated by signature, not cookies) ──
async function paypalWebhook(env, request, ctx) {
  const raw = await request.text();
  let event; try { event = JSON.parse(raw); } catch { return new Response('bad json', { status: 400 }); }
  if (!env.PAYPAL_WEBHOOK_ID) return new Response('not configured', { status: 503 });
  if (!(await pay.verifyPayPalWebhook(env, request, event))) {
    console.warn('PayPal webhook signature rejected');
    return new Response('invalid signature', { status: 400 });
  }
  (await pay.paypalOneTimeEvent(env, ctx, event))
    || (await subs.paypalSubscriptionEvent(env, ctx, event))
    || (await payouts.payoutEvent(env, ctx, event));
  return new Response('ok');
}

async function stripeWebhook(env, request, ctx) {
  const raw = await request.text();
  if (!(await pay.verifyStripeSignature(env, request.headers.get('Stripe-Signature'), raw))) {
    console.warn('Stripe webhook signature rejected');
    return new Response('invalid signature', { status: 400 });
  }
  const event = JSON.parse(raw);
  (await pay.stripeOneTimeEvent(env, ctx, event)) || (await subs.stripeSubscriptionEvent(env, ctx, event));
  return new Response('ok');
}

async function route(request, env, ctx) {
  const url = new URL(request.url);
  const p = url.pathname;
  const m = request.method;

  if (m === 'POST' && p === '/webhooks/paypal') return paypalWebhook(env, request, ctx);
  if (m === 'POST' && p === '/webhooks/stripe') return stripeWebhook(env, request, ctx);

  // Merchant API: authenticated by API key
  if (p.startsWith('/api/v1/')) return app.apiV1(env, request, p);

  // Google sign-in redirects and email links (top-level GET navigations)
  if (m === 'GET' && p === '/api/auth/google/start') return auth.googleStart(env, request);
  if (m === 'GET' && p === '/api/auth/google/callback') return auth.googleCallback(env, request, ctx);
  if (m === 'GET' && p === '/api/auth/verify') return auth.verifyEmail(env, request);

  if (m !== 'GET' && m !== 'HEAD') checkCsrf(request, env);

  switch (`${m} ${p}`) {
    case 'GET /api/config': return app.publicConfig(env);
    case 'POST /api/human': return verifyHuman(env, request);
    case 'GET /api/me': return app.me(env, request);
    case 'PATCH /api/me': return app.updateProfile(env, request);
    case 'GET /api/dashboard': return app.dashboard(env, request);
    case 'GET /api/feed': return app.feed(env, request);

    case 'POST /api/auth/signup': return auth.signup(env, request, ctx);
    case 'POST /api/auth/login': return auth.login(env, request);
    case 'POST /api/auth/logout': return auth.logout(env, request);
    case 'POST /api/auth/forgot': return auth.forgot(env, request, ctx);
    case 'POST /api/auth/reset': return auth.resetPassword(env, request);
    case 'POST /api/auth/resend-verification': return auth.resendVerification(env, request, ctx);

    case 'POST /api/account/password': return account.changePassword(env, request);
    case 'POST /api/account/email': return account.changeEmail(env, request, ctx);
    case 'PATCH /api/account/settings': return account.updateSettings(env, request);
    case 'POST /api/account/logout-all': return account.logoutAll(env, request);
    case 'DELETE /api/account': return account.deleteAccount(env, request, ctx);

    case 'POST /api/items': return app.createItem(env, request);
    case 'POST /api/withdrawals': return app.requestWithdrawal(env, request, ctx);
    case 'POST /api/api-key': return app.createApiKey(env, request);
    case 'DELETE /api/api-key': return app.revokeApiKey(env, request);
    case 'PUT /api/webhook': return app.setWebhook(env, request);

    case 'POST /api/pay/paypal/order': return pay.paypalCreateOrder(env, request);
    case 'POST /api/pay/paypal/capture': return pay.paypalCapture(env, request, ctx);
    case 'POST /api/pay/stripe/intent': return pay.stripeCreateIntent(env, request);
    case 'POST /api/pay/stripe/confirm': return pay.stripeConfirm(env, request, ctx);
    case 'POST /api/pay/paypal/subscribe': return subs.paypalSubscribeStart(env, request);
    case 'POST /api/pay/paypal/subscribe/activate': return subs.paypalSubscribeActivate(env, request, ctx);
    case 'POST /api/pay/stripe/subscribe': return subs.stripeSubscribe(env, request);
    case 'POST /api/pay/stripe/subscribe/confirm': return subs.stripeSubscribeConfirm(env, request, ctx);
    case 'POST /api/public/subscriptions/lookup': return subs.publicLookup(env, request);
    case 'POST /api/public/subscriptions/cancel': return subs.publicCancel(env, request);

    case 'GET /api/admin/withdrawals': return admin.listWithdrawals(env, request);
    case 'GET /api/admin/users': return admin.listUsers(env, request);
    case 'GET /api/admin/transactions': return admin.listTransactions(env, request);
    case 'GET /api/admin/stats': return admin.stats(env, request);
  }

  // Routes with an id: /api/<resource>/<id>[/<action>]
  const seg = p.split('/').filter(Boolean);
  const [, res, rid] = seg;
  if (seg[0] === 'api' && rid) {
    if (res === 'items' && m === 'DELETE' && seg.length === 3) return app.deleteItem(env, request, rid);
    if (res === 'subscriptions' && m === 'POST' && seg[3] === 'cancel') return subs.merchantCancel(env, request, rid);
    if (res === 'follows' && seg.length === 3 && (m === 'POST' || m === 'DELETE')) return app.follow(env, request, rid, m === 'POST');
    if (res === 'public' && m === 'GET' && rid === 'items' && seg[3]) return app.publicItem(env, request, seg[3]);
    if (res === 'public' && m === 'GET' && rid === 'profiles' && seg[3]) return app.publicProfile(env, request, seg[3]);
    if (res === 'admin' && rid === 'withdrawals' && seg[3] && m === 'POST') {
      if (!seg[4]) return admin.updateWithdrawal(env, request, seg[3], ctx);
      if (seg[4] === 'payout') return payouts.sendPayout(env, request, seg[3], ctx);
      if (seg[4] === 'payout-refresh') return payouts.refreshPayoutRoute(env, request, seg[3], ctx);
    }
    if (res === 'admin' && rid === 'users' && seg[3]) {
      if (m === 'POST' && seg[4] === 'suspend') return admin.setSuspended(env, request, seg[3]);
      if (m === 'POST' && seg[4] === 'adjust') return admin.adjustBalance(env, request, seg[3]);
      if (m === 'POST' && seg[4] === 'hold') return admin.setHold(env, request, seg[3]);
      if (m === 'DELETE' && !seg[4]) return admin.deleteUser(env, request, seg[3]);
    }
  }
  return json({ error: 'Not found' }, 404);
}

export default {
  async fetch(request, env, ctx) {
    const p = new URL(request.url).pathname;
    if (!p.startsWith('/api/') && !p.startsWith('/webhooks/')) return env.ASSETS.fetch(request);
    try {
      return await route(request, env, ctx);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message, code: e.code }, e.status);
      console.error('Unhandled error', p, e?.stack || e);
      return json({ error: 'Something went wrong. Please try again.' }, 500);
    }
  },

  // Every 5 minutes: retry merchant webhooks, check PayPal payouts, daily admin summary, tidy up
  async scheduled(event, env, ctx) {
    const job = async (name, fn) => { try { await fn(); } catch (e) { console.error(`cron ${name}`, e?.stack || e); } };
    ctx.waitUntil((async () => {
      await job('webhooks', () => retryDueWebhooks(env));
      await job('payouts', () => payouts.pollPayouts(env, ctx));
      await job('digest', () => dailyDigest(env));
      await job('subscriptions', () => subs.cleanupPending(env));
      await job('cleanup', async () => {
        const now = Date.now();
        await env.DB.batch([
          env.DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(now),
          env.DB.prepare('DELETE FROM auth_tokens WHERE expires_at < ?').bind(now - 86400000),
          env.DB.prepare('DELETE FROM rate_limits WHERE window_start < ?').bind(now - 86400000),
          env.DB.prepare("DELETE FROM orders WHERE status = 'created' AND created_at < ?").bind(new Date(now - 30 * 86400000).toISOString()),
        ]);
      });
    })());
  },
};
