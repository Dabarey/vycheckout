// Daily summary for the admin (instant alerts are sent where the problem happens).
import { alert, formatMoney } from './email.js';


export async function dailyDigest(env) {
  const now = new Date();
  // Sent once a day at DIGEST_HOUR_UTC (default 3 = about 8:30 in Sri Lanka)
  if (now.getUTCHours() !== parseInt(env.DIGEST_HOUR_UTC ?? '3', 10)) return;
  const today = now.toISOString().slice(0, 10);
  const last = await env.DB.prepare("SELECT value FROM settings WHERE key = 'digest_day'").first();
  if (last?.value === today) return;
  await env.DB.prepare("INSERT INTO settings (key, value) VALUES ('digest_day', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").bind(today).run();

  const since = new Date(now.getTime() - 86400000).toISOString();
  const q = (sql, ...a) => env.DB.prepare(sql).bind(...a);
  const [pending, approved, failedHooks, mismatches, signups, volume, negative, failedPayouts] = await env.DB.batch([
    q("SELECT currency, COUNT(*) AS n, SUM(amount_minor) AS total, MIN(created_at) AS oldest FROM withdrawals WHERE status = 'pending' GROUP BY currency"),
    q("SELECT COUNT(*) AS n FROM withdrawals WHERE status = 'approved'"),
    q("SELECT COUNT(*) AS n FROM webhook_deliveries WHERE status = 'failed' AND created_at >= ?", since),
    q("SELECT COUNT(*) AS n FROM audit_log WHERE action = 'payment_amount_mismatch' AND created_at >= ?", since),
    q('SELECT COUNT(*) AS n FROM users WHERE created_at >= ?', since),
    q('SELECT currency, COUNT(*) AS n, SUM(gross_minor) AS gross, SUM(fee_minor) AS fees FROM transactions WHERE created_at >= ? GROUP BY currency', since),
    q(`SELECT COUNT(*) AS n FROM (SELECT user_id, currency, SUM(amt) AS b FROM (
         SELECT user_id, currency, amount_minor AS amt FROM ledger
         UNION ALL SELECT user_id, currency, -amount_minor FROM withdrawals WHERE status != 'rejected'
       ) GROUP BY user_id, currency HAVING b < 0)`),
    q("SELECT COUNT(*) AS n FROM withdrawals WHERE status = 'approved' AND payout_status IN ('FAILED','RETURNED','BLOCKED','DENIED','UNCLAIMED')"),
  ]);

  const lines = [];
  const vol = volume.results.map(v => `${formatMoney(v.gross, v.currency)} (${v.n} payments, fees ${formatMoney(v.fees, v.currency)})`);
  lines.push(`Last 24h: ${vol.length ? vol.join(', ') : 'no payments'} · ${signups.results[0].n} new signups`);
  for (const p of pending.results) {
    const days = Math.floor((now - new Date(p.oldest)) / 86400000);
    lines.push(`Pending withdrawals: ${p.n} × ${p.currency} = ${formatMoney(p.total, p.currency)} (oldest ${days} day${days === 1 ? '' : 's'})`);
  }
  if (approved.results[0].n) lines.push(`Approved, not yet paid: ${approved.results[0].n}`);
  if (failedPayouts.results[0].n) lines.push(`⚠️ PayPal payouts needing attention: ${failedPayouts.results[0].n}`);
  if (failedHooks.results[0].n) lines.push(`⚠️ Merchant webhooks that failed after all retries: ${failedHooks.results[0].n}`);
  if (mismatches.results[0].n) lines.push(`⚠️ Payment amount mismatches: ${mismatches.results[0].n}`);
  if (negative.results[0].n) lines.push(`⚠️ Merchants with a negative balance: ${negative.results[0].n}`);
  await alert(env, `Daily summary ${today}`, lines);
}
