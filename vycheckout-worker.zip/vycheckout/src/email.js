// Transactional email through Resend (https://resend.com). Set RESEND_API_KEY and EMAIL_FROM.
// Without RESEND_API_KEY nothing is sent; in local dev (DEV=true) the message is printed to the console.

const escHtml = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export async function sendEmail(env, { to, subject, text, html }) {
  if (!env.RESEND_API_KEY) {
    if (env.DEV === 'true') console.log(`[email to ${to}] ${subject}\n${text}`);
    else console.warn('Email not sent (RESEND_API_KEY not set):', subject);
    return false;
  }
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: env.EMAIL_FROM || 'VyCheckout <noreply@example.com>', to: [to], subject, text, html }),
    });
    if (!res.ok) console.error('Resend error', res.status, await res.text());
    return res.ok;
  } catch (e) {
    console.error('Email failed', e);
    return false;
  }
}

export function linkEmail(env, to, subject, intro, buttonText, url) {
  return sendEmail(env, {
    to, subject,
    text: `${intro}\n\n${url}\n\nIf you didn't ask for this, you can ignore this email.`,
    html: `<div style="font-family:system-ui,sans-serif;max-width:480px">
      <p>${escHtml(intro)}</p>
      <p><a href="${escHtml(url)}" style="display:inline-block;background:#2563eb;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">${escHtml(buttonText)}</a></p>
      <p style="color:#666;font-size:13px">If you didn't ask for this, you can ignore this email.</p></div>`,
  });
}

// Short notice to the admin addresses (new signups, withdrawal requests)
export function notifyAdmin(env, subject, lines) {
  const to = (env.ADMIN_EMAILS || '').split(',').map(s => s.trim()).filter(Boolean)[0];
  if (!to) return Promise.resolve(false);
  const text = lines.join('\n');
  return sendEmail(env, { to, subject, text, html: `<pre style="font-family:system-ui,sans-serif">${escHtml(text)}</pre>` });
}
