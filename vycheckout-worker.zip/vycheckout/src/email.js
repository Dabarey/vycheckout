// Transactional email through Resend (https://resend.com). Set RESEND_API_KEY and EMAIL_FROM.
// Without RESEND_API_KEY nothing is sent; in local dev (DEV=true) the message is printed to the console.

const escHtml = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export async function sendEmail(env, { to, subject, text, html }) {
  if (!env.RESEND_API_KEY) {
    if (env.DEV === 'true') console.log(`[email to ${to}] ${subject}\n${text}`);
    else console.warn('Email not sent (RESEND_API_KEY not set):', subject);
    return false;
  }
  try {
    const res = await fetch(env.RESEND_API_URL || 'https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: env.EMAIL_FROM || 'VyCheckout <noreply@example.com>', to: [to], subject, text, html }),
    });
    if (!res.ok) console.error('Resend error', res.status, await res.text());
    return res.ok;
  } catch (e) {
    console.error('Email failed', e);
    return false;
  }
}

export function linkEmail(env, to, subject, intro, buttonText, url) {
  return sendEmail(env, {
    to, subject,
    text: `${intro}\n\n${url}\n\nIf you didn't ask for this, you can ignore this email.`,
    html: `<div style="font-family:system-ui,sans-serif;max-width:480px">
      <p>${escHtml(intro)}</p>
      <p><a href="${escHtml(url)}" style="display:inline-block;background:#2563eb;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">${escHtml(buttonText)}</a></p>
      <p style="color:#666;font-size:13px">If you didn't ask for this, you can ignore this email.</p></div>`,
  });
}

// Short notice to the admin addresses (new signups, withdrawal requests)
export function notifyAdmin(env, subject, lines) {
  const to = (env.ADMIN_EMAILS || '').split(',').map(s => s.trim()).filter(Boolean)[0];
  if (!to) return Promise.resolve(false);
  const text = lines.join('\n');
  return sendEmail(env, { to, subject, text, html: `<pre style="font-family:system-ui,sans-serif">${escHtml(text)}</pre>` });
}

// ── Alerts to the admin: email plus an optional Slack/Discord-style webhook (ALERT_WEBHOOK_URL) ──
export async function alert(env, subject, lines) {
  const jobs = [notifyAdmin(env, `⚠️ VyCheckout: ${subject}`, lines)];
  if (env.ALERT_WEBHOOK_URL) {
    const text = `*${subject}*\n${lines.join('\n')}`;
    jobs.push(fetch(env.ALERT_WEBHOOK_URL, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, content: text.slice(0, 1900) }),   // "text" for Slack, "content" for Discord
    }).catch(e => console.error('Alert webhook failed', e)));
  }
  await Promise.all(jobs);
}

const money = (minor, currency) => {
  const zero = currency === 'JPY';
  const v = zero ? minor : minor / 100;
  try { return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(v); }
  catch { return `${v.toFixed(zero ? 0 : 2)} ${currency}`; }
};

// Receipt to the person who paid
export function payerReceiptEmail(env, { to, business, description, grossMinor, currency, txnId, method, cancelUrl }) {
  const lines = [
    `Thanks for your payment to ${business}.`,
    '',
    `Amount: ${money(grossMinor, currency)}`,
    `For: ${description || '—'}`,
    `Paid with: ${method}`,
    `Reference: ${txnId}`,
    `Date: ${new Date().toUTCString()}`,
  ];
  if (cancelUrl) lines.push('', `This is a recurring subscription. To cancel it, open: ${cancelUrl}`);
  const text = lines.join('\n');
  const html = `<div style="font-family:system-ui,sans-serif;max-width:480px;line-height:1.55">
    <h2 style="margin:0 0 8px">Payment received ✓</h2>
    <p>Thanks for your payment to <strong>${escHtml(business)}</strong>.</p>
    <table style="border-collapse:collapse;font-size:14px">
      <tr><td style="padding:3px 12px 3px 0;color:#666">Amount</td><td><strong>${escHtml(money(grossMinor, currency))}</strong></td></tr>
      <tr><td style="padding:3px 12px 3px 0;color:#666">For</td><td>${escHtml(description || '—')}</td></tr>
      <tr><td style="padding:3px 12px 3px 0;color:#666">Paid with</td><td>${escHtml(method)}</td></tr>
      <tr><td style="padding:3px 12px 3px 0;color:#666">Reference</td><td style="font-family:monospace;font-size:12px">${escHtml(txnId)}</td></tr>
    </table>
    ${cancelUrl ? `<p style="font-size:13px;color:#555">This is a recurring subscription. <a href="${escHtml(cancelUrl)}">Cancel it here</a> any time.</p>` : ''}
  </div>`;
  return sendEmail(env, { to, subject: `Receipt: ${money(grossMinor, currency)} to ${business}`, text, html });
}

// "You got paid" to the merchant
export function saleAlertEmail(env, { to, description, grossMinor, netMinor, currency, availableAt, payerName, appUrl }) {
  const when = availableAt ? new Date(availableAt).toDateString() : 'now';
  const lines = [
    `You received ${money(grossMinor, currency)} for ${description || 'a payment'}${payerName ? ` from ${payerName}` : ''}.`,
    `After the platform fee you get ${money(netMinor, currency)}, available to withdraw: ${when}.`,
    '',
    `Dashboard: ${appUrl}`,
    'You can turn these emails off in Account settings.',
  ];
  return sendEmail(env, {
    to, subject: `💰 You got paid ${money(grossMinor, currency)}`,
    text: lines.join('\n'),
    html: `<div style="font-family:system-ui,sans-serif;max-width:480px;line-height:1.55"><p>${lines.slice(0, 2).map(escHtml).join('<br>')}</p>
      <p><a href="${escHtml(appUrl)}">Open your dashboard</a></p><p style="font-size:12px;color:#777">You can turn these emails off in Account settings.</p></div>`,
  });
}

export { money as formatMoney };
