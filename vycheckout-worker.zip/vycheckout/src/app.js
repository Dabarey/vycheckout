// Signed-in user features, public pages and the merchant API (/api/v1, Bearer API key).
import {
  HttpError, bad, forbidden, notFound, unauthorized, json, readJson, newId, nowIso, randomToken, sha256Hex,
  toMinor, toMajor, isZeroDecimal, cleanCurrency, str, emailOf, safeWebhookUrl, rateLimit, CURRENCIES,
} from './lib.js';
import { requireUser, getSessionUser, selfView, appUrl } from './auth.js';
import { notifyAdmin } from './email.js';

const CYCLES = ['WEEKLY', 'MONTHLY', 'QUARTERLY', 'ANNUALLY'];
const MAX_ITEMS_PER_USER = 1000;

// Minimum withdrawals, in the currency's main unit (×100 for yen, which has no cents)
export function minWithdraw(env, method, currency) {
  const base = method === 'paypal' ? parseFloat(env.MIN_WITHDRAW_PAYPAL || '100') : parseFloat(env.MIN_WITHDRAW_BANK || '500');
  return isZeroDecimal(currency) ? base * 100 : base;
}

// ── Views (money converted to main units for the browser) ──
const itemView = i => ({
  id: i.id, type: i.type, name: i.name, description: i.description, note: i.note,
  amount: toMajor(i.amount_minor, i.currency), currency: i.currency, cycle: i.cycle,
  custom_amount: !!i.custom_amount, expires_at: i.expires_at, source: i.source, created_at: i.created_at,
  expired: !!(i.expires_at && new Date(i.expires_at) < new Date()),
});
const txnView = t => ({
  id: t.id, item_id: t.item_id, item_type: t.item_type, description: t.description, payer_name: t.payer_name,
  currency: t.currency, gross_amount: toMajor(t.gross_minor, t.currency), fee_amount: toMajor(t.fee_minor, t.currency),
  net_amount: toMajor(t.net_minor, t.currency), refunded_amount: toMajor(t.refunded_minor, t.currency),
  payment_method: t.provider === 'paypal' ? 'PayPal' : 'Card', status: t.status, created_at: t.created_at,
});
const wdView = w => ({
  id: w.id, currency: w.currency, amount: toMajor(w.amount_minor, w.currency), method: w.method,
  destination: w.destination, status: w.status, notes: w.notes, admin_note: w.admin_note, created_at: w.created_at,
});
const sumsToMajor = rows => Object.fromEntries(rows.filter(r => r.total).map(r => [r.currency, toMajor(r.total, r.currency)]));

export async function balances(env, userId) {
  const { results } = await env.DB.prepare(
    `SELECT currency, SUM(amt) AS total FROM (
       SELECT currency, amount_minor AS amt FROM ledger WHERE user_id = ?1
       UNION ALL
       SELECT currency, -amount_minor AS amt FROM withdrawals WHERE user_id = ?1 AND status != 'rejected'
     ) GROUP BY currency`
  ).bind(userId).all();
  return results;
}

// ── GET /api/me ──
export async function me(env, request) {
  const u = await getSessionUser(env, request);
  return json({ user: u ? selfView(env, u) : null });
}

// ── GET /api/dashboard: everything the merchant dashboard shows ──
export async function dashboard(env, request) {
  const u = await requireUser(env, request);
  const monthStart = new Date(); monthStart.setUTCDate(1); monthStart.setUTCHours(0, 0, 0, 0);
  const q = (sql, ...args) => env.DB.prepare(sql).bind(...args);
  const [items, txns, wds, refs, bal, earned, refEarned, month, followers, key] = await env.DB.batch([
    q('SELECT * FROM items WHERE user_id = ? AND deleted_at IS NULL ORDER BY created_at DESC', u.id),
    q('SELECT * FROM transactions WHERE owner_id = ? ORDER BY created_at DESC LIMIT 500', u.id),
    q('SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC', u.id),
    q('SELECT full_name, business_name, created_at FROM users WHERE referrer_id = ? AND deleted_at IS NULL ORDER BY created_at DESC', u.id),
    q(`SELECT currency, SUM(amt) AS total FROM (
         SELECT currency, amount_minor AS amt FROM ledger WHERE user_id = ?1
         UNION ALL SELECT currency, -amount_minor FROM withdrawals WHERE user_id = ?1 AND status != 'rejected'
       ) GROUP BY currency`, u.id),
    q("SELECT currency, SUM(amount_minor) AS total FROM ledger WHERE user_id = ? AND kind IN ('sale','refund') GROUP BY currency", u.id),
    q("SELECT currency, SUM(amount_minor) AS total FROM ledger WHERE user_id = ? AND kind IN ('referral','referral_reversal') GROUP BY currency", u.id),
    q("SELECT currency, SUM(amount_minor) AS total FROM ledger WHERE user_id = ? AND kind IN ('sale','refund') AND created_at >= ? GROUP BY currency", u.id, monthStart.toISOString()),
    q('SELECT COUNT(*) AS n FROM follows WHERE following_id = ?', u.id),
    q('SELECT prefix, created_at, last_used_at FROM api_keys WHERE user_id = ? AND revoked_at IS NULL ORDER BY created_at DESC LIMIT 1', u.id),
  ]);
  const apiCounts = {
    cols: items.results.filter(i => i.source === 'api' && i.type === 'col').length,
    lnks: items.results.filter(i => i.source === 'api' && i.type === 'lnk').length,
  };
  return json({
    user: selfView(env, u),
    items: items.results.map(itemView),
    transactions: txns.results.map(txnView),
    withdrawals: wds.results.map(wdView),
    referrals: refs.results,
    balances: sumsToMajor(bal.results),
    earned: sumsToMajor(earned.results),
    ref_earned: sumsToMajor(refEarned.results),
    month: sumsToMajor(month.results),
    followers: followers.results[0]?.n || 0,
    api_key: key.results[0] || null,
    api_counts: apiCounts,
    webhook: { url: u.webhook_url, secret: u.webhook_secret },
  });
}

// ── PATCH /api/me ──
export async function updateProfile(env, request) {
  const u = await requireUser(env, request);
  const b = await readJson(request);
  const business_name = str(b.business_name, { max: 80, field: 'Business name' }) || u.business_name;
  const bio = str(b.bio, { max: 300, field: 'Bio' }) || null;
  const avatar = str(b.avatar, { max: 16, field: 'Avatar' }) || null;
  await env.DB.prepare('UPDATE users SET business_name = ?, bio = ?, avatar = ? WHERE id = ?').bind(business_name, bio, avatar, u.id).run();
  return json({ ok: true });
}

// ── Items ──
async function createItemFor(env, userId, b, source) {
  await rateLimit(env, `items:${userId}`, 100, 3600000);
  const type = String(b.type || '');
  if (!['col', 'sub', 'lnk'].includes(type)) throw bad('Invalid item type');
  const name = str(b.name, { max: 100, required: true, field: 'Name' });
  const currency = cleanCurrency(b.currency);
  const custom = !!b.custom_amount && type !== 'sub';
  let amount = 0;
  if (!custom) {
    amount = toMinor(b.amount, currency);
    const min = 50;  // smallest unit: 0.50 in most currencies, ¥50 in yen
    const max = toMinor(parseFloat(env.MAX_PAYMENT || '10000'), currency);
    if (amount < min) throw bad(`Minimum amount is ${toMajor(min, currency)} ${currency}`);
    if (amount > max) throw bad(`Maximum amount is ${toMajor(max, currency)} ${currency}`);
  }
  const cycle = type === 'sub' ? (CYCLES.includes(String(b.cycle).toUpperCase()) ? String(b.cycle).toUpperCase() : 'MONTHLY') : null;
  const days = parseInt(b.expires_days || '0', 10);
  if (!(days >= 0 && days <= 365)) throw bad('Invalid expiry');
  const expires_at = type === 'lnk' && days ? new Date(Date.now() + days * 86400000).toISOString() : null;
  const count = await env.DB.prepare('SELECT COUNT(*) AS n FROM items WHERE user_id = ? AND deleted_at IS NULL').bind(userId).first();
  if (count.n >= MAX_ITEMS_PER_USER) throw bad('You have reached the item limit. Delete some old items first.');

  const id = newId();
  await env.DB.prepare(
    `INSERT INTO items (id, user_id, type, name, description, note, amount_minor, currency, cycle, custom_amount, expires_at, source)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`
  ).bind(id, userId, type, name, str(b.description, { max: 500, field: 'Description' }) || null,
         str(b.note, { max: 500, field: 'Note' }) || null, amount, currency, cycle, custom ? 1 : 0, expires_at, source).run();
  return env.DB.prepare('SELECT * FROM items WHERE id = ?').bind(id).first();
}

export async function createItem(env, request) {
  const u = await requireUser(env, request);
  const item = await createItemFor(env, u.id, await readJson(request), 'web');
  return json({ item: itemView(item) });
}

export async function deleteItem(env, request, id) {
  const u = await requireUser(env, request);
  const r = await env.DB.prepare('UPDATE items SET deleted_at = ? WHERE id = ? AND user_id = ? AND deleted_at IS NULL').bind(nowIso(), id, u.id).run();
  if (!r.meta.changes) throw notFound('Item not found');
  return json({ ok: true });
}

// ── Withdrawals ──
const BANK_FIELDS = ['holder', 'routing', 'account', 'type', 'sort', 'iban', 'bic', 'ifsc', 'bank', 'swift', 'address'];

export async function requestWithdrawal(env, request, ctx) {
  const u = await requireUser(env, request);
  if (!u.email_verified) throw forbidden('Confirm your email address before withdrawing. Check your inbox for the link.');
  await rateLimit(env, `wd:${u.id}`, 5, 3600000);
  const b = await readJson(request);
  const currency = cleanCurrency(b.currency);
  const method = b.method === 'bank' ? 'bank' : b.method === 'paypal' ? 'paypal' : null;
  if (!method) throw bad('Choose PayPal or bank transfer');
  const amount = toMinor(b.amount, currency);
  const min = minWithdraw(env, method, currency);
  if (amount < toMinor(min, currency)) throw bad(`Minimum for ${method === 'paypal' ? 'PayPal' : 'bank'} is ${min} ${currency}`);

  let destination, country, bankDetails = null;
  if (method === 'paypal') {
    destination = emailOf(b.paypal_email);
    country = 'PayPal';
  } else {
    country = str(b.country, { max: 60, required: true, field: 'Country' });
    const d = {};
    for (const k of BANK_FIELDS) {
      const v = str(b.bank_details?.[k], { max: 120, field: 'Bank details' });
      if (v) d[k] = v;
    }
    if (!d.holder || !(d.account || d.iban)) throw bad('Please complete your bank details');
    bankDetails = JSON.stringify(d);
    const acct = String(d.account || d.iban);
    destination = `${d.holder} ****${acct.slice(-4)}`;
  }
  const notes = str(b.notes, { max: 500, field: 'Notes' }) || null;

  // Single statement: the row is written only if the balance covers it, so two requests can't overdraw.
  const id = newId();
  const r = await env.DB.prepare(
    `INSERT INTO withdrawals (id, user_id, currency, amount_minor, method, destination, country, bank_details, notes)
     SELECT ?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9
     WHERE (SELECT COALESCE(SUM(amount_minor), 0) FROM ledger WHERE user_id = ?2 AND currency = ?3)
         - (SELECT COALESCE(SUM(amount_minor), 0) FROM withdrawals WHERE user_id = ?2 AND currency = ?3 AND status != 'rejected')
         >= ?4`
  ).bind(id, u.id, currency, amount, method === 'paypal' ? 'PayPal' : 'Bank Transfer', destination, country, bankDetails, notes).run();
  if (!r.meta.changes) throw bad(`Insufficient ${currency} balance`, 'insufficient_funds');

  ctx.waitUntil(notifyAdmin(env, 'New withdrawal request', [
    `User: ${u.full_name} <${u.email}>`, `Amount: ${toMajor(amount, currency)} ${currency}`, `Method: ${method}`, `To: ${destination}`,
  ]));
  return json({ ok: true, id });
}

// ── API keys (only a hash is stored; the full key is shown once) ──
export async function createApiKey(env, request) {
  const u = await requireUser(env, request);
  await rateLimit(env, `apikey:${u.id}`, 10, 3600000);
  const key = `vy_live_${randomToken(32)}`;
  await env.DB.batch([
    env.DB.prepare('UPDATE api_keys SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL').bind(nowIso(), u.id),
    env.DB.prepare('INSERT INTO api_keys (id, user_id, prefix, key_hash) VALUES (?,?,?,?)').bind(newId(), u.id, key.slice(0, 16), await sha256Hex(key)),
  ]);
  return json({ key, prefix: key.slice(0, 16) });
}
export async function revokeApiKey(env, request) {
  const u = await requireUser(env, request);
  await env.DB.prepare('UPDATE api_keys SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL').bind(nowIso(), u.id).run();
  return json({ ok: true });
}

// ── Merchant webhook settings ──
export async function setWebhook(env, request) {
  const u = await requireUser(env, request);
  const b = await readJson(request);
  const raw = str(b.url, { max: 500 });
  if (!raw) {
    await env.DB.prepare('UPDATE users SET webhook_url = NULL, webhook_secret = NULL WHERE id = ?').bind(u.id).run();
    return json({ url: null, secret: null });
  }
  const url = safeWebhookUrl(raw);
  const secret = b.rotate || !u.webhook_secret ? `whsec_${randomToken(24)}` : u.webhook_secret;
  await env.DB.prepare('UPDATE users SET webhook_url = ?, webhook_secret = ? WHERE id = ?').bind(url, secret, u.id).run();
  return json({ url, secret });
}

// ── Social: follows and feed ──
export async function follow(env, request, targetId, on) {
  const u = await requireUser(env, request);
  if (targetId === u.id) throw bad("You can't follow yourself");
  if (on) {
    const t = await env.DB.prepare('SELECT id FROM users WHERE id = ? AND deleted_at IS NULL').bind(targetId).first();
    if (!t) throw notFound('User not found');
    await env.DB.prepare('INSERT OR IGNORE INTO follows (follower_id, following_id) VALUES (?,?)').bind(u.id, targetId).run();
  } else {
    await env.DB.prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?').bind(u.id, targetId).run();
  }
  return json({ ok: true, following: on });
}

export async function feed(env, request) {
  const u = await requireUser(env, request);
  const since = new Date(Date.now() - 30 * 86400000).toISOString();
  const following = await env.DB.prepare('SELECT COUNT(*) AS n FROM follows WHERE follower_id = ?').bind(u.id).first();
  const { results } = await env.DB.prepare(
    `SELECT i.*, o.business_name AS owner_business, o.full_name AS owner_name, o.avatar AS owner_avatar, o.ref_code AS owner_ref
     FROM follows f JOIN items i ON i.user_id = f.following_id JOIN users o ON o.id = i.user_id
     WHERE f.follower_id = ? AND i.type IN ('col','lnk') AND i.deleted_at IS NULL AND i.created_at > ?
       AND (i.expires_at IS NULL OR i.expires_at > ?) AND o.suspended = 0 AND o.deleted_at IS NULL
     ORDER BY i.created_at DESC LIMIT 50`
  ).bind(u.id, since, nowIso()).all();
  return json({
    following_count: following.n,
    items: results.map(i => ({ ...itemView(i), owner: { id: i.user_id, business_name: i.owner_business || i.owner_name, avatar: i.owner_avatar, ref_code: i.owner_ref } })),
  });
}

// ── Public pages ──
export async function publicItem(env, request, id) {
  const i = await env.DB.prepare(
    `SELECT i.*, u.business_name, u.full_name FROM items i JOIN users u ON u.id = i.user_id
     WHERE i.id = ? AND i.deleted_at IS NULL AND u.suspended = 0 AND u.deleted_at IS NULL`
  ).bind(String(id).slice(0, 64)).first();
  if (!i) throw notFound('This link may have been removed.');
  return json({ item: { ...itemView(i), source: undefined }, business: i.business_name || i.full_name || 'VyCheckout' });
}

export async function publicProfile(env, request, code) {
  const p = await env.DB.prepare(
    'SELECT id, full_name, business_name, avatar, bio, ref_code FROM users WHERE ref_code = ? AND deleted_at IS NULL AND suspended = 0'
  ).bind(String(code).toUpperCase().slice(0, 12)).first();
  if (!p) throw notFound('Profile not found');
  const viewer = await getSessionUser(env, request);
  const q = (sql, ...a) => env.DB.prepare(sql).bind(...a);
  const [items, followers, following, isFollowing] = await env.DB.batch([
    q(`SELECT * FROM items WHERE user_id = ? AND type IN ('col','lnk') AND deleted_at IS NULL
         AND (expires_at IS NULL OR expires_at > ?) ORDER BY created_at DESC LIMIT 100`, p.id, nowIso()),
    q('SELECT COUNT(*) AS n FROM follows WHERE following_id = ?', p.id),
    q('SELECT COUNT(*) AS n FROM follows WHERE follower_id = ?', p.id),
    q('SELECT COUNT(*) AS n FROM follows WHERE follower_id = ? AND following_id = ?', viewer?.id || '', p.id),
  ]);
  return json({
    profile: p,
    items: items.results.map(i => ({ ...itemView(i), source: undefined })),
    followers: followers.results[0].n, following: following.results[0].n,
    is_following: !!isFollowing.results[0].n, is_me: viewer?.id === p.id,
  });
}

export function publicConfig(env) {
  return json({
    paypal_client_id: env.PAYPAL_CLIENT_ID || null,
    stripe_publishable_key: env.STRIPE_PUBLISHABLE_KEY || null,
    google_enabled: !!(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET),
    fee_pct: parseInt(env.PLATFORM_FEE_BPS || '2400', 10) / 100,
    referral_pct: parseInt(env.REFERRAL_BPS || '100', 10) / 100,
    min_withdraw: { paypal: parseFloat(env.MIN_WITHDRAW_PAYPAL || '100'), bank: parseFloat(env.MIN_WITHDRAW_BANK || '500') },
    currencies: CURRENCIES,
  });
}

// ═════════════ Merchant API: Authorization: Bearer vy_live_… ═════════════
async function apiUser(env, request) {
  const m = (request.headers.get('Authorization') || '').match(/^Bearer\s+(vy_live_[A-Za-z0-9_-]{20,80})$/);
  if (!m) throw unauthorized('Missing or invalid API key');
  const row = await env.DB.prepare(
    `SELECT u.*, k.id AS key_id FROM api_keys k JOIN users u ON u.id = k.user_id
     WHERE k.key_hash = ? AND k.revoked_at IS NULL AND u.suspended = 0 AND u.deleted_at IS NULL`
  ).bind(await sha256Hex(m[1])).first();
  if (!row) throw unauthorized('Missing or invalid API key');
  await rateLimit(env, `api:${row.key_id}`, 120, 60000);
  await env.DB.prepare('UPDATE api_keys SET last_used_at = ? WHERE id = ?').bind(nowIso(), row.key_id).run();
  return row;
}

export async function apiV1(env, request, path) {
  const u = await apiUser(env, request);
  const base = appUrl(env, request);
  if (request.method === 'GET' && path === '/api/v1/balance') {
    return json({ balances: sumsToMajor(await balances(env, u.id)) });
  }
  if (request.method === 'GET' && path === '/api/v1/transactions') {
    const limit = Math.min(Math.max(parseInt(new URL(request.url).searchParams.get('limit') || '50', 10) || 50, 1), 200);
    const { results } = await env.DB.prepare('SELECT * FROM transactions WHERE owner_id = ? ORDER BY created_at DESC LIMIT ?').bind(u.id, limit).all();
    return json({ transactions: results.map(txnView) });
  }
  if (request.method === 'POST' && (path === '/api/v1/collections' || path === '/api/v1/links')) {
    const b = await readJson(request);
    const type = path.endsWith('collections') ? 'col' : 'lnk';
    const item = await createItemFor(env, u.id, { ...b, type }, 'api');
    return json({ ...itemView(item), url: `${base}/?pay=${type}:${item.id}` }, 201);
  }
  throw notFound('Unknown API endpoint');
}
