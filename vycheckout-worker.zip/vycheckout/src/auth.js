// Accounts: email + password, Google sign-in, sessions, password reset, email verification.
import {
  HttpError, bad, unauthorized, forbidden, json, readJson, newId, nowIso, randomToken, sha256Hex,
  hashPassword, verifyPassword, str, emailOf, rateLimit, clientIp,
} from './lib.js';
import { requireHuman } from './human.js';
import { linkEmail, notifyAdmin } from './email.js';

const SESSION_COOKIE = 'vy_session';
const SESSION_DAYS = 30;
const OAUTH_COOKIE = 'vy_oauth';

export const appUrl = (env, request) => (env.APP_URL || new URL(request.url).origin).replace(/\/$/, '');

function cookie(name, value, { maxAge, path = '/' } = {}) {
  return `${name}=${value}; Path=${path}; HttpOnly; Secure; SameSite=Lax${maxAge != null ? `; Max-Age=${maxAge}` : ''}`;
}
function readCookie(request, name) {
  const raw = request.headers.get('Cookie') || '';
  for (const part of raw.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return v.join('=');
  }
  return null;
}

// ── Admin = a verified email that is flagged in the DB or listed in ADMIN_EMAILS ──
export function isAdmin(env, user) {
  if (!user || !user.email_verified) return false;
  if (user.is_admin) return true;
  const list = (env.ADMIN_EMAILS || '').toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
  return list.includes(String(user.email).toLowerCase());
}

// What the browser is allowed to know about the signed-in user
export function selfView(env, u) {
  return {
    id: u.id, email: u.email, email_verified: !!u.email_verified,
    full_name: u.full_name, business_name: u.business_name, bio: u.bio, avatar: u.avatar,
    ref_code: u.ref_code, has_referrer: !!u.referrer_id, created_at: u.created_at,
    is_admin: isAdmin(env, u), has_password: !!u.password_hash, has_google: !!u.google_sub,
    notify_sales: u.notify_sales == null ? true : !!u.notify_sales,
  };
}

// ── Sessions ──
export async function createSession(env, userId) {
  const token = randomToken(32);
  await env.DB.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?,?,?)')
    .bind(await sha256Hex(token), userId, Date.now() + SESSION_DAYS * 86400000).run();
  return cookie(SESSION_COOKIE, token, { maxAge: SESSION_DAYS * 86400 });
}

export const clearSessionCookie = () => cookie(SESSION_COOKIE, '', { maxAge: 0 });

export async function getSessionUser(env, request) {
  const token = readCookie(request, SESSION_COOKIE);
  if (!token) return null;
  const row = await env.DB.prepare(
    `SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires_at > ? AND u.suspended = 0 AND u.deleted_at IS NULL`
  ).bind(await sha256Hex(token), Date.now()).first();
  return row || null;
}

export async function requireUser(env, request) {
  const u = await getSessionUser(env, request);
  if (!u) throw unauthorized();
  return u;
}
export async function requireAdmin(env, request) {
  const u = await requireUser(env, request);
  if (!isAdmin(env, u)) throw forbidden('Admin only');
  return u;
}

async function genRefCode(env) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let i = 0; i < 10; i++) {
    const a = new Uint8Array(6); crypto.getRandomValues(a);
    const code = [...a].map(b => alphabet[b % alphabet.length]).join('');
    const taken = await env.DB.prepare('SELECT 1 FROM users WHERE ref_code = ?').bind(code).first();
    if (!taken) return code;
  }
  throw new HttpError(500, 'Could not create account, please try again');
}

async function referrerIdFor(env, code) {
  const c = String(code || '').toUpperCase().trim();
  if (!c || !/^[A-Z0-9]{4,12}$/.test(c)) return null;
  const r = await env.DB.prepare('SELECT id FROM users WHERE ref_code = ? AND deleted_at IS NULL').bind(c).first();
  return r ? r.id : null;
}

async function issueToken(env, userId, purpose, ttlMs) {
  const token = randomToken(32);
  await env.DB.prepare('INSERT INTO auth_tokens (token_hash, user_id, purpose, expires_at) VALUES (?,?,?,?)')
    .bind(await sha256Hex(token), userId, purpose, Date.now() + ttlMs).run();
  return token;
}
// Marks the token used and returns its user id, or null if invalid/expired/used.
async function consumeToken(env, token, purpose) {
  if (!token || typeof token !== 'string' || token.length > 100) return null;
  const row = await env.DB.prepare(
    `UPDATE auth_tokens SET used_at = ? WHERE token_hash = ? AND purpose = ? AND used_at IS NULL AND expires_at > ?
     RETURNING user_id`
  ).bind(nowIso(), await sha256Hex(token), purpose, Date.now()).first();
  return row ? row.user_id : null;
}

export async function sendVerification(env, request, user) {
  const token = await issueToken(env, user.id, 'verify', 3 * 86400000);
  const url = `${appUrl(env, request)}/api/auth/verify?token=${encodeURIComponent(token)}`;
  await linkEmail(env, user.email, 'Confirm your VyCheckout email', 'Confirm your email address to finish setting up VyCheckout.', 'Confirm email', url);
}

// ── Handlers ──
export async function signup(env, request, ctx) {
  const ip = clientIp(request);
  await rateLimit(env, `signup:${ip}`, 10, 3600000);
  await requireHuman(env, request);
  const b = await readJson(request);
  const full_name = str(b.full_name, { max: 80, required: true, field: 'Name' });
  const business_name = str(b.business_name, { max: 80, required: true, field: 'Business name' });
  const email = emailOf(b.email);
  const password = String(b.password || '');
  if (password.length < 8) throw bad('Password must be 8+ characters');
  if (password.length > 200) throw bad('Password is too long');

  const exists = await env.DB.prepare('SELECT 1 FROM users WHERE email = ?').bind(email).first();
  if (exists) throw bad('An account with this email already exists. Try signing in instead.', 'email_taken');

  const id = newId();
  const user = {
    id, email, full_name, business_name, ref_code: await genRefCode(env),
    referrer_id: await referrerIdFor(env, b.ref), password_hash: await hashPassword(password),
  };
  await env.DB.prepare(
    `INSERT INTO users (id, email, password_hash, full_name, business_name, ref_code, referrer_id)
     VALUES (?,?,?,?,?,?,?)`
  ).bind(id, email, user.password_hash, full_name, business_name, user.ref_code, user.referrer_id).run();

  ctx.waitUntil(sendVerification(env, request, user));
  ctx.waitUntil(notifyAdmin(env, 'New VyCheckout signup', [`Name: ${full_name}`, `Business: ${business_name}`, `Email: ${email}`]));

  const row = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
  return json({ user: selfView(env, row) }, 200, { 'Set-Cookie': await createSession(env, id) });
}

export async function login(env, request) {
  const b = await readJson(request);
  const email = emailOf(b.email);
  const ip = clientIp(request);
  await requireHuman(env, request);
  await rateLimit(env, `login-ip:${ip}`, 30, 900000);
  await rateLimit(env, `login-email:${email}`, 10, 900000);
  const u = await env.DB.prepare('SELECT * FROM users WHERE email = ? AND deleted_at IS NULL').bind(email).first();
  // Always run the hash so response time doesn't reveal whether the email exists
  const ok = await verifyPassword(String(b.password || ''), u?.password_hash || 'pbkdf2$100000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=');
  if (!u || !ok) throw bad('Wrong email or password', 'bad_credentials');
  if (u.suspended) throw forbidden('This account is suspended. Contact support.');
  return json({ user: selfView(env, u) }, 200, { 'Set-Cookie': await createSession(env, u.id) });
}

export async function logout(env, request) {
  const token = readCookie(request, SESSION_COOKIE);
  if (token) await env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(await sha256Hex(token)).run();
  return json({ ok: true }, 200, { 'Set-Cookie': cookie(SESSION_COOKIE, '', { maxAge: 0 }) });
}

export async function forgot(env, request, ctx) {
  const b = await readJson(request);
  const email = emailOf(b.email);
  await requireHuman(env, request);
  await rateLimit(env, `forgot:${clientIp(request)}`, 10, 3600000);
  await rateLimit(env, `forgot-email:${email}`, 3, 3600000);
  const u = await env.DB.prepare('SELECT id, email FROM users WHERE email = ? AND deleted_at IS NULL AND suspended = 0').bind(email).first();
  if (u) {
    const token = await issueToken(env, u.id, 'reset', 3600000);
    const url = `${appUrl(env, request)}/?reset=${encodeURIComponent(token)}`;
    ctx.waitUntil(linkEmail(env, u.email, 'Reset your VyCheckout password', 'Someone asked to reset your VyCheckout password. The link works for 1 hour.', 'Choose a new password', url));
  }
  return json({ ok: true }); // same answer whether or not the email exists
}

export async function resetPassword(env, request) {
  const b = await readJson(request);
  const password = String(b.password || '');
  if (password.length < 8) throw bad('Password must be 8+ characters');
  if (password.length > 200) throw bad('Password is too long');
  const userId = await consumeToken(env, b.token, 'reset');
  if (!userId) throw bad('This reset link is invalid or has expired. Request a new one.', 'bad_token');
  // Clicking the emailed link proves the address, so mark it verified. Sign out every other session.
  await env.DB.batch([
    env.DB.prepare('UPDATE users SET password_hash = ?, email_verified = 1 WHERE id = ?').bind(await hashPassword(password), userId),
    env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(userId),
  ]);
  const u = await env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(userId).first();
  return json({ user: selfView(env, u) }, 200, { 'Set-Cookie': await createSession(env, userId) });
}

export async function verifyEmail(env, request) {
  const token = new URL(request.url).searchParams.get('token');
  const userId = await consumeToken(env, token, 'verify');
  if (userId) await env.DB.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').bind(userId).run();
  return Response.redirect(`${appUrl(env, request)}/?verified=${userId ? '1' : '0'}`, 302);
}

export async function resendVerification(env, request, ctx) {
  const u = await requireUser(env, request);
  if (u.email_verified) return json({ ok: true, already: true });
  await rateLimit(env, `verify-resend:${u.id}`, 3, 3600000);
  ctx.waitUntil(sendVerification(env, request, u));
  return json({ ok: true });
}

// ── Google sign-in (OAuth 2.0 authorization code flow) ──
export async function googleStart(env, request) {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) throw bad('Google sign-in is not set up');
  const url = new URL(request.url);
  const state = randomToken(24);
  const ref = (url.searchParams.get('ref') || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
  const auth = new URL(env.GOOGLE_AUTH_URL || 'https://accounts.google.com/o/oauth2/v2/auth');
  auth.search = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID,
    redirect_uri: `${appUrl(env, request)}/api/auth/google/callback`,
    response_type: 'code', scope: 'openid email profile', state, prompt: 'select_account',
  }).toString();
  return new Response(null, {
    status: 302,
    headers: { Location: auth.toString(), 'Set-Cookie': cookie(OAUTH_COOKIE, `${state}.${ref}`, { maxAge: 600, path: '/api/auth/google' }) },
  });
}

export async function googleCallback(env, request, ctx) {
  const base = appUrl(env, request);
  const fail = reason => new Response(null, {
    status: 302, headers: { Location: `${base}/?login_error=${encodeURIComponent(reason)}`, 'Set-Cookie': cookie(OAUTH_COOKIE, '', { maxAge: 0, path: '/api/auth/google' }) },
  });
  const url = new URL(request.url);
  const [state, ref] = (readCookie(request, OAUTH_COOKIE) || '').split('.');
  if (!state || state !== url.searchParams.get('state') || !url.searchParams.get('code')) return fail('Google sign-in expired. Please try again.');

  const tokRes = await fetch(env.GOOGLE_TOKEN_URL || 'https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code: url.searchParams.get('code'), client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET,
      redirect_uri: `${base}/api/auth/google/callback`, grant_type: 'authorization_code',
    }),
  });
  if (!tokRes.ok) return fail('Google sign-in failed. Please try again.');
  const tok = await tokRes.json();
  const infoRes = await fetch(env.GOOGLE_USERINFO_URL || 'https://openidconnect.googleapis.com/v1/userinfo', {
    headers: { Authorization: `Bearer ${tok.access_token}` },
  });
  if (!infoRes.ok) return fail('Google sign-in failed. Please try again.');
  const info = await infoRes.json();
  if (!info.sub || !info.email || info.email_verified !== true) return fail('Your Google email is not verified.');
  const email = String(info.email).toLowerCase();

  let u = await env.DB.prepare('SELECT * FROM users WHERE google_sub = ?').bind(info.sub).first()
       || await env.DB.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
  if (u && (u.deleted_at || u.suspended)) return fail('This account is suspended. Contact support.');

  if (u && !u.google_sub) {
    // Link Google to an existing email account. If that email was never verified, someone else may have
    // registered it, so drop their password and sessions — the Google owner now controls the account.
    const stmts = [env.DB.prepare('UPDATE users SET google_sub = ?, email_verified = 1' + (u.email_verified ? '' : ', password_hash = NULL') + ' WHERE id = ?').bind(info.sub, u.id)];
    if (!u.email_verified) stmts.push(env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(u.id));
    await env.DB.batch(stmts);
  } else if (!u) {
    const id = newId();
    const name = String(info.name || '').slice(0, 80);
    await env.DB.prepare(
      `INSERT INTO users (id, email, email_verified, google_sub, full_name, business_name, ref_code, referrer_id)
       VALUES (?,?,1,?,?,?,?,?)`
    ).bind(id, email, info.sub, name, name, await genRefCode(env), await referrerIdFor(env, ref)).run();
    u = { id };
    ctx.waitUntil(notifyAdmin(env, 'New VyCheckout signup (Google)', [`Name: ${name}`, `Email: ${email}`]));
  }

  const headers = new Headers({ Location: `${base}/` });
  headers.append('Set-Cookie', await createSession(env, u.id));
  headers.append('Set-Cookie', cookie(OAUTH_COOKIE, '', { maxAge: 0, path: '/api/auth/google' }));
  return new Response(null, { status: 302, headers });
}
