// One-click PayPal payouts for approved PayPal withdrawals (needs PayPal Payouts enabled on your account).
// Bank transfers stay manual: the admin sends them and clicks "Mark as Paid".
import { HttpError, bad, notFound, json, nowIso, majorString, toMajor, audit } from './lib.js';
import { requireAdmin } from './auth.js';
import { pp } from './payments.js';
import { alert, sendEmail, formatMoney } from './email.js';

const FAILED = ['FAILED', 'RETURNED', 'BLOCKED', 'REFUNDED', 'REVERSED', 'DENIED', 'CANCELED'];

export async function sendPayout(env, request, id, ctx) {
  const admin = await requireAdmin(env, request);
  // Claim the withdrawal first so a double click can't send the money twice
  const claim = await env.DB.prepare(
    `UPDATE withdrawals SET payout_status = 'SENDING', payout_error = NULL, updated_at = ?
     WHERE id = ? AND status = 'approved' AND method = 'PayPal'
       AND (payout_status IS NULL OR payout_status IN (${FAILED.map(() => '?').join(',')}))`
  ).bind(nowIso(), id, ...FAILED).run();
  if (!claim.meta.changes) throw bad('Only approved PayPal withdrawals that have not been sent can be paid out.');
  const w = await env.DB.prepare('SELECT * FROM withdrawals WHERE id = ?').bind(id).first();

  const r = await pp(env, '/v1/payments/payouts', {
    method: 'POST',
    body: {
      sender_batch_header: {
        sender_batch_id: `${w.id}-${Date.now()}`,   // must be unique per attempt
        email_subject: 'You have a payout from VyCheckout',
        email_message: 'Your VyCheckout withdrawal has been sent.',
      },
      items: [{
        recipient_type: 'EMAIL', receiver: w.destination, sender_item_id: w.id, note: 'VyCheckout withdrawal',
        amount: { value: majorString(w.amount_minor, w.currency), currency: w.currency },
      }],
    },
  });
  if (!r.ok || !r.data?.batch_header?.payout_batch_id) {
    const msg = r.data?.message || r.data?.name || `HTTP ${r.status}`;
    await env.DB.prepare("UPDATE withdrawals SET payout_status = 'FAILED', payout_error = ? WHERE id = ?").bind(String(msg).slice(0, 300), id).run();
    await audit(env, admin.id, 'payout_send_failed', id, { msg });
    throw new HttpError(502, `PayPal refused the payout: ${msg}. Is PayPal Payouts enabled on your account?`);
  }
  await env.DB.prepare("UPDATE withdrawals SET payout_batch_id = ?, payout_status = 'PENDING' WHERE id = ?").bind(r.data.batch_header.payout_batch_id, id).run();
  await audit(env, admin.id, 'payout_sent', id, { batch: r.data.batch_header.payout_batch_id });
  return json({ ok: true, payout_status: 'PENDING' });
}

// Reads the payout's status from PayPal and applies it
export async function refreshPayout(env, ctx, w) {
  if (!w.payout_batch_id) return w.payout_status;
  const r = await pp(env, `/v1/payments/payouts/${encodeURIComponent(w.payout_batch_id)}`);
  const it = r.ok ? r.data?.items?.[0] : null;
  if (!it) return w.payout_status;
  const status = it.transaction_status;
  if (status === w.payout_status) return status;
  if (status === 'SUCCESS') {
    const done = await env.DB.prepare(
      "UPDATE withdrawals SET status = 'completed', payout_status = 'SUCCESS', payout_error = NULL, updated_at = ? WHERE id = ? AND status = 'approved'"
    ).bind(nowIso(), w.id).run();
    if (done.meta.changes) {
      const u = await env.DB.prepare('SELECT email FROM users WHERE id = ?').bind(w.user_id).first();
      if (u?.email) ctx.waitUntil(sendEmail(env, {
        to: u.email, subject: `Your withdrawal of ${formatMoney(w.amount_minor, w.currency)} was sent`,
        text: `We sent ${formatMoney(w.amount_minor, w.currency)} to your PayPal account (${w.destination}).`,
      }));
    }
  } else if (FAILED.includes(status) || status === 'UNCLAIMED') {
    const err = it.errors?.message || (status === 'UNCLAIMED' ? 'The PayPal email has no PayPal account yet. PayPal returns the money after 30 days if it is not claimed.' : status);
    await env.DB.prepare('UPDATE withdrawals SET payout_status = ?, payout_error = ? WHERE id = ?').bind(status, String(err).slice(0, 300), w.id).run();
    ctx.waitUntil(alert(env, `PayPal payout ${status.toLowerCase()}`, [
      `Withdrawal ${w.id}: ${formatMoney(w.amount_minor, w.currency)} to ${w.destination}`, `Reason: ${err}`,
      FAILED.includes(status) ? 'The money is back in your PayPal. Retry or reject it in the admin panel.' : 'Ask the user to open a PayPal account with that email.',
    ]));
  } else {
    await env.DB.prepare('UPDATE withdrawals SET payout_status = ? WHERE id = ?').bind(status, w.id).run();
  }
  return status;
}

export async function refreshPayoutRoute(env, request, id, ctx) {
  await requireAdmin(env, request);
  const w = await env.DB.prepare('SELECT * FROM withdrawals WHERE id = ?').bind(id).first();
  if (!w) throw notFound('Withdrawal not found');
  return json({ payout_status: await refreshPayout(env, ctx, w) });
}

// PayPal webhook PAYMENT.PAYOUTS-ITEM.* → re-read the payout from PayPal (don't trust the event body alone)
export async function payoutEvent(env, ctx, event) {
  if (!event.event_type?.startsWith('PAYMENT.PAYOUTS-ITEM.') && !event.event_type?.startsWith('PAYMENT.PAYOUTSBATCH.')) return false;
  const res = event.resource || {};
  const batch = res.payout_batch_id || res.batch_header?.payout_batch_id;
  const w = batch && await env.DB.prepare('SELECT * FROM withdrawals WHERE payout_batch_id = ?').bind(batch).first();
  if (w) await refreshPayout(env, ctx, w);
  return true;
}

// Cron: check payouts that are still in flight (covers missed webhooks)
export async function pollPayouts(env, ctx) {
  const { results } = await env.DB.prepare(
    "SELECT * FROM withdrawals WHERE payout_batch_id IS NOT NULL AND payout_status IN ('PENDING','ONHOLD','UNCLAIMED') AND status = 'approved' ORDER BY updated_at LIMIT 10"
  ).all();
  for (const w of results) await refreshPayout(env, ctx, w).catch(e => console.error('payout poll', e));
}
