// Payments. The browser never decides a price and never records a payment:
//  1. The Worker creates the PayPal order / Stripe PaymentIntent from the item's price stored in D1.
//  2. A payment is recorded only after the Worker confirms it with PayPal/Stripe (capture/retrieve call
//     or a signature-verified webhook). Recording is idempotent, so both paths can run safely.
import {
  HttpError, bad, notFound, json, readJson, newId, nowIso, toMinor, toMajor, majorString,
  isZeroDecimal, rateLimit, clientIp, hmacHex, safeEqual, audit,
} from './lib.js';
import { enqueueWebhook } from './webhooks.js';

const feeBps = env => parseInt(env.PLATFORM_FEE_BPS || '2400', 10);   // 24%
const refBps = env => parseInt(env.REFERRAL_BPS || '100', 10);        // 1%

// ── Items and orders ──
async function payableItem(env, itemId) {
  if (typeof itemId !== 'string' || itemId.length > 64) throw notFound('This link is not valid.');
  const item = await env.DB.prepare(
    `SELECT i.*, u.business_name, u.full_name, u.suspended, u.deleted_at AS owner_deleted
     FROM items i JOIN users u ON u.id = i.user_id WHERE i.id = ? AND i.deleted_at IS NULL`
  ).bind(itemId).first();
  if (!item || item.owner_deleted) throw notFound('This link may have been removed.');
  if (item.suspended) throw bad('This merchant cannot accept payments right now.', 'merchant_unavailable');
  if (item.expires_at && new Date(item.expires_at) < new Date()) throw bad('This link has expired. Ask the sender for a new one.', 'expired');
  return item;
}

function priceFor(env, item, requested) {
  if (!item.custom_amount) return item.amount_minor;
  if (requested == null || requested === '') throw bad('Enter an amount');
  const minor = toMinor(requested, item.currency);
  const min = isZeroDecimal(item.currency) ? 50 : 100;                        // 1.00 (¥50)
  const max = toMinor(parseFloat(env.MAX_PAYMENT || '10000'), item.currency);
  if (minor < min) throw bad(`Minimum amount is ${majorString(min, item.currency)} ${item.currency}`);
  if (minor > max) throw bad(`Maximum amount is ${majorString(max, item.currency)} ${item.currency}`);
  return minor;
}

async function newOrder(env, request, provider) {
  await rateLimit(env, `order:${clientIp(request)}`, 40, 600000);
  const b = await readJson(request);
  const item = await payableItem(env, b.item_id);
  const amount = priceFor(env, item, b.amount);
  if (amount <= 0) throw bad('Invalid amount');
  const order = { id: newId(), item_id: item.id, owner_id: item.user_id, provider, amount_minor: amount, currency: item.currency };
  await env.DB.prepare('INSERT INTO orders (id, item_id, owner_id, provider, amount_minor, currency) VALUES (?,?,?,?,?,?)')
    .bind(order.id, order.item_id, order.owner_id, provider, amount, item.currency).run();
  return { order, item };
}

// ── Recording a verified payment (idempotent) ──
// p = { provider, providerRef, grossMinor, currency, payerName, payerEmail }
export async function recordPayment(env, ctx, order, p) {
  if (p.currency !== order.currency || p.grossMinor !== order.amount_minor) {
    await audit(env, null, 'payment_amount_mismatch', order.id, { expected: [order.amount_minor, order.currency], got: [p.grossMinor, p.currency], ref: p.providerRef });
    throw new HttpError(409, 'Payment amount did not match the order. It has been flagged for review.', 'amount_mismatch');
  }
  const item = await env.DB.prepare('SELECT id, type, name FROM items WHERE id = ?').bind(order.item_id).first();
  const owner = await env.DB.prepare('SELECT id, referrer_id FROM users WHERE id = ?').bind(order.owner_id).first();
  const gross = p.grossMinor;
  const fee = Math.round(gross * feeBps(env) / 10000);
  const net = gross - fee;
  const referrer = owner?.referrer_id && owner.referrer_id !== owner.id ? owner.referrer_id : null;
  const refAmt = referrer ? Math.round(gross * refBps(env) / 10000) : 0;

  const txnId = newId();
  const onlyIfNew = 'WHERE EXISTS (SELECT 1 FROM transactions WHERE id = ?)';
  const stmts = [
    env.DB.prepare(
      `INSERT OR IGNORE INTO transactions
        (id, owner_id, item_id, item_type, order_id, provider, provider_ref, description, payer_name, payer_email,
         currency, gross_minor, fee_minor, net_minor, referrer_id, referral_minor)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    ).bind(txnId, order.owner_id, order.item_id, item?.type || null, order.id, p.provider, p.providerRef, item?.name || null,
           (p.payerName || '').slice(0, 120) || null, (p.payerEmail || '').slice(0, 254) || null,
           order.currency, gross, fee, net, referrer, refAmt),
    env.DB.prepare(`INSERT INTO ledger (id, user_id, currency, amount_minor, kind, txn_id) SELECT ?,?,?,?,'sale',? ${onlyIfNew}`)
      .bind(newId(), order.owner_id, order.currency, net, txnId, txnId),
    env.DB.prepare("UPDATE orders SET status = 'paid' WHERE id = ?").bind(order.id),
  ];
  if (referrer && refAmt > 0) {
    stmts.push(env.DB.prepare(`INSERT INTO ledger (id, user_id, currency, amount_minor, kind, txn_id) SELECT ?,?,?,?,'referral',? ${onlyIfNew}`)
      .bind(newId(), referrer, order.currency, refAmt, txnId, txnId));
  }
  await env.DB.batch(stmts);

  const txn = await env.DB.prepare('SELECT * FROM transactions WHERE provider = ? AND provider_ref = ?').bind(p.provider, p.providerRef).first();
  if (txn.id === txnId) {
    await enqueueWebhook(env, ctx, txn.owner_id, 'payment.succeeded', {
      transaction_id: txn.id, item_id: txn.item_id, item_type: txn.item_type, description: txn.description,
      amount: toMajor(gross, txn.currency), net_amount: toMajor(net, txn.currency), currency: txn.currency,
      payer_name: txn.payer_name, payment_method: p.provider === 'paypal' ? 'PayPal' : 'Card', created_at: txn.created_at,
    });
  }
  return txn;
}

// Refunds: take back the merchant's net share and the referral, in proportion to the refunded amount.
async function applyRefund(env, ctx, txn, provider, refundRef, amountMinor) {
  const remaining = txn.gross_minor - txn.refunded_minor;
  const d = Math.min(Math.max(0, amountMinor), remaining);
  if (d <= 0) return;
  const refundId = newId();
  const merchantBack = Math.round(d * txn.net_minor / txn.gross_minor);
  const referralBack = txn.referral_minor ? Math.round(d * txn.referral_minor / txn.gross_minor) : 0;
  const onlyIfNew = 'WHERE EXISTS (SELECT 1 FROM refunds WHERE id = ?)';
  const stmts = [
    env.DB.prepare('INSERT OR IGNORE INTO refunds (id, provider, provider_refund_id, txn_id, amount_minor) VALUES (?,?,?,?,?)')
      .bind(refundId, provider, refundRef, txn.id, d),
    env.DB.prepare(`INSERT INTO ledger (id, user_id, currency, amount_minor, kind, txn_id, note) SELECT ?,?,?,?,'refund',?,? ${onlyIfNew}`)
      .bind(newId(), txn.owner_id, txn.currency, -merchantBack, txn.id, refundRef, refundId),
    env.DB.prepare(
      `UPDATE transactions SET refunded_minor = refunded_minor + ?,
         status = CASE WHEN refunded_minor + ? >= gross_minor THEN 'refunded' ELSE 'partially_refunded' END
       WHERE id = ? AND EXISTS (SELECT 1 FROM refunds WHERE id = ?)`
    ).bind(d, d, txn.id, refundId),
  ];
  if (txn.referrer_id && referralBack > 0) {
    stmts.push(env.DB.prepare(`INSERT INTO ledger (id, user_id, currency, amount_minor, kind, txn_id, note) SELECT ?,?,?,?,'referral_reversal',?,? ${onlyIfNew}`)
      .bind(newId(), txn.referrer_id, txn.currency, -referralBack, txn.id, refundRef, refundId));
  }
  await env.DB.batch(stmts);
  const applied = await env.DB.prepare('SELECT 1 FROM refunds WHERE id = ?').bind(refundId).first();
  if (applied) await enqueueWebhook(env, ctx, txn.owner_id, 'payment.refunded', {
    transaction_id: txn.id, refunded_amount: toMajor(d, txn.currency), currency: txn.currency,
  });
}

// What the payer's browser gets back (enough for the receipt)
async function receiptView(env, txn) {
  const owner = await env.DB.prepare('SELECT business_name, full_name FROM users WHERE id = ?').bind(txn.owner_id).first();
  return {
    id: txn.id, amount: toMajor(txn.gross_minor, txn.currency), currency: txn.currency, description: txn.description,
    business: owner?.business_name || owner?.full_name || 'VyCheckout', method: txn.provider === 'paypal' ? 'PayPal' : 'Card',
    created_at: txn.created_at,
  };
}

// ═════════════════ PayPal ═════════════════
const ppBase = env => env.PAYPAL_API_BASE || (env.PAYPAL_ENV === 'sandbox' ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com');
let ppTokenCache = null;

async function ppToken(env) {
  if (ppTokenCache && ppTokenCache.cid === env.PAYPAL_CLIENT_ID && ppTokenCache.exp > Date.now() + 60000) return ppTokenCache.token;
  if (!env.PAYPAL_CLIENT_ID || !env.PAYPAL_CLIENT_SECRET) throw new HttpError(503, 'PayPal is not set up', 'paypal_unconfigured');
  const res = await fetch(`${ppBase(env)}/v1/oauth2/token`, {
    method: 'POST',
    headers: { Authorization: 'Basic ' + btoa(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_CLIENT_SECRET}`), 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials',
  });
  if (!res.ok) { console.error('PayPal auth failed', res.status, await res.text()); throw new HttpError(502, 'PayPal is unavailable, please try again'); }
  const d = await res.json();
  ppTokenCache = { cid: env.PAYPAL_CLIENT_ID, token: d.access_token, exp: Date.now() + d.expires_in * 1000 };
  return d.access_token;
}

async function pp(env, path, { method = 'GET', body, requestId } = {}) {
  const headers = { Authorization: `Bearer ${await ppToken(env)}`, 'Content-Type': 'application/json' };
  if (requestId) headers['PayPal-Request-Id'] = requestId;
  const res = await fetch(`${ppBase(env)}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data = null; try { data = text ? JSON.parse(text) : null; } catch {}
  return { ok: res.ok, status: res.status, data };
}

export async function paypalCreateOrder(env, request) {
  const { order, item } = await newOrder(env, request, 'paypal');
  const r = await pp(env, '/v2/checkout/orders', {
    method: 'POST', requestId: `create-${order.id}`,
    body: {
      intent: 'CAPTURE',
      purchase_units: [{
        reference_id: order.id, custom_id: order.id,
        description: String(item.name).slice(0, 127),
        amount: { currency_code: order.currency, value: majorString(order.amount_minor, order.currency) },
      }],
    },
  });
  if (!r.ok || !r.data?.id) { console.error('PayPal create failed', r.status, JSON.stringify(r.data)); throw new HttpError(502, 'Could not start PayPal checkout'); }
  await env.DB.prepare('UPDATE orders SET provider_order_id = ? WHERE id = ?').bind(r.data.id, order.id).run();
  return json({ id: r.data.id });
}

// Reads a COMPLETED capture out of a PayPal order and records it
async function recordFromPayPalOrder(env, ctx, order, ppOrder) {
  const pu = ppOrder?.purchase_units?.[0];
  const cap = pu?.payments?.captures?.[0];
  if (!cap) throw new HttpError(402, 'The payment was not completed.', 'not_captured');
  if (cap.status === 'PENDING') return { pending: true };
  if (cap.status !== 'COMPLETED') throw new HttpError(402, 'The payment was not completed.', 'not_captured');
  if ((cap.custom_id || pu.custom_id) !== order.id) throw new HttpError(409, 'Payment does not belong to this order.');
  const payer = ppOrder.payer || {};
  const txn = await recordPayment(env, ctx, order, {
    provider: 'paypal', providerRef: cap.id,
    grossMinor: toMinor(cap.amount.value, cap.amount.currency_code), currency: cap.amount.currency_code,
    payerName: [payer.name?.given_name, payer.name?.surname].filter(Boolean).join(' ') || payer.email_address || '',
    payerEmail: payer.email_address || '',
  });
  return { txn };
}

export async function paypalCapture(env, request, ctx) {
  const b = await readJson(request);
  if (typeof b.order_id !== 'string' || b.order_id.length > 64) throw bad('Invalid order');
  const order = await env.DB.prepare("SELECT * FROM orders WHERE provider = 'paypal' AND provider_order_id = ?").bind(b.order_id).first();
  if (!order) throw notFound('Order not found');

  let r = await pp(env, `/v2/checkout/orders/${encodeURIComponent(b.order_id)}/capture`, { method: 'POST', requestId: `capture-${order.id}` });
  if (!r.ok && r.data?.details?.some(d => d.issue === 'ORDER_ALREADY_CAPTURED')) {
    r = await pp(env, `/v2/checkout/orders/${encodeURIComponent(b.order_id)}`);
  }
  if (!r.ok) {
    const issue = r.data?.details?.[0]?.issue;
    if (issue === 'INSTRUMENT_DECLINED') throw new HttpError(402, 'Your payment method was declined. Please try another one.', 'declined');
    console.error('PayPal capture failed', r.status, JSON.stringify(r.data));
    throw new HttpError(502, 'PayPal could not complete the payment. You have not been charged.');
  }
  const res = await recordFromPayPalOrder(env, ctx, order, r.data);
  if (res.pending) return json({ pending: true, message: 'PayPal is still processing this payment. It will appear once PayPal confirms it.' });
  return json({ receipt: await receiptView(env, res.txn) });
}

export async function paypalWebhook(env, request, ctx) {
  const raw = await request.text();
  let event; try { event = JSON.parse(raw); } catch { return new Response('bad json', { status: 400 }); }
  if (!env.PAYPAL_WEBHOOK_ID) return new Response('not configured', { status: 503 });
  const h = n => request.headers.get(n);
  const v = await pp(env, '/v1/notifications/verify-webhook-signature', {
    method: 'POST',
    body: {
      auth_algo: h('paypal-auth-algo'), cert_url: h('paypal-cert-url'), transmission_id: h('paypal-transmission-id'),
      transmission_sig: h('paypal-transmission-sig'), transmission_time: h('paypal-transmission-time'),
      webhook_id: env.PAYPAL_WEBHOOK_ID, webhook_event: event,
    },
  });
  if (!v.ok || v.data?.verification_status !== 'SUCCESS') {
    console.warn('PayPal webhook signature rejected');
    return new Response('invalid signature', { status: 400 });
  }

  const res = event.resource || {};
  if (event.event_type === 'PAYMENT.CAPTURE.COMPLETED') {
    const order = res.custom_id && await env.DB.prepare("SELECT * FROM orders WHERE id = ? AND provider = 'paypal'").bind(res.custom_id).first();
    if (order) {
      await recordPayment(env, ctx, order, {
        provider: 'paypal', providerRef: res.id,
        grossMinor: toMinor(res.amount.value, res.amount.currency_code), currency: res.amount.currency_code,
      }).catch(e => { if (!(e instanceof HttpError)) throw e; });
    }
  } else if (event.event_type === 'PAYMENT.CAPTURE.REFUNDED') {
    const captureId = (res.links || []).find(l => l.rel === 'up')?.href?.split('/').pop();
    const txn = captureId && await env.DB.prepare("SELECT * FROM transactions WHERE provider = 'paypal' AND provider_ref = ?").bind(captureId).first();
    if (txn) await applyRefund(env, ctx, txn, 'paypal', res.id, toMinor(res.amount.value, res.amount.currency_code));
  } else if (event.event_type === 'PAYMENT.CAPTURE.REVERSED') {
    const txn = await env.DB.prepare("SELECT * FROM transactions WHERE provider = 'paypal' AND provider_ref = ?").bind(res.id).first();
    if (txn) await applyRefund(env, ctx, txn, 'paypal', `reversal-${event.id}`, txn.gross_minor);
  }
  return new Response('ok');
}

// ═════════════════ Stripe ═════════════════
const stripeBase = env => env.STRIPE_API_BASE || 'https://api.stripe.com';

async function stripe(env, path, { method = 'GET', form, idempotencyKey } = {}) {
  if (!env.STRIPE_SECRET_KEY) throw new HttpError(503, 'Card payments are not set up', 'stripe_unconfigured');
  const headers = { Authorization: `Bearer ${env.STRIPE_SECRET_KEY}` };
  if (form) headers['Content-Type'] = 'application/x-www-form-urlencoded';
  if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;
  const res = await fetch(`${stripeBase(env)}${path}`, { method, headers, body: form ? new URLSearchParams(form).toString() : undefined });
  const data = await res.json().catch(() => null);
  return { ok: res.ok, status: res.status, data };
}

export async function stripeCreateIntent(env, request) {
  const { order, item } = await newOrder(env, request, 'stripe');
  const r = await stripe(env, '/v1/payment_intents', {
    method: 'POST', idempotencyKey: `pi-${order.id}`,
    form: {
      amount: String(order.amount_minor), currency: order.currency.toLowerCase(),
      description: String(item.name).slice(0, 200), 'payment_method_types[]': 'card',
      'metadata[order_id]': order.id, 'metadata[item_id]': item.id,
    },
  });
  if (!r.ok || !r.data?.client_secret) { console.error('Stripe create failed', r.status, JSON.stringify(r.data?.error)); throw new HttpError(502, 'Could not start card payment'); }
  await env.DB.prepare('UPDATE orders SET provider_order_id = ? WHERE id = ?').bind(r.data.id, order.id).run();
  return json({ client_secret: r.data.client_secret, intent_id: r.data.id });
}

async function recordFromIntent(env, ctx, pi, payer = {}) {
  const orderId = pi?.metadata?.order_id;
  const order = orderId && await env.DB.prepare("SELECT * FROM orders WHERE id = ? AND provider = 'stripe'").bind(orderId).first();
  if (!order || order.provider_order_id !== pi.id) throw notFound('Order not found');
  if (pi.status !== 'succeeded') throw new HttpError(402, 'The card payment did not complete.', 'not_paid');
  return recordPayment(env, ctx, order, {
    provider: 'stripe', providerRef: pi.id,
    grossMinor: pi.amount_received, currency: String(pi.currency).toUpperCase(),
    payerName: payer.name || '', payerEmail: payer.email || pi.receipt_email || '',
  });
}

// Called by the browser after Stripe.js confirms the card; the Worker re-checks with Stripe itself.
export async function stripeConfirm(env, request, ctx) {
  const b = await readJson(request);
  if (typeof b.intent_id !== 'string' || !/^pi_[A-Za-z0-9]+$/.test(b.intent_id)) throw bad('Invalid payment');
  const r = await stripe(env, `/v1/payment_intents/${b.intent_id}?expand[]=latest_charge`);
  if (!r.ok) throw notFound('Payment not found');
  const bd = r.data.latest_charge?.billing_details || {};
  const txn = await recordFromIntent(env, ctx, r.data, { name: bd.name, email: bd.email });
  return json({ receipt: await receiptView(env, txn) });
}

async function verifyStripeSignature(env, header, raw) {
  if (!env.STRIPE_WEBHOOK_SECRET || !header) return false;
  const parts = Object.fromEntries(header.split(',').map(p => p.split('=')).filter(p => p.length === 2).map(([k, v]) => [k.trim(), v.trim()]));
  const sigs = header.split(',').filter(p => p.trim().startsWith('v1=')).map(p => p.trim().slice(3));
  const t = parseInt(parts.t, 10);
  if (!t || Math.abs(Date.now() / 1000 - t) > 300) return false;          // 5-minute tolerance
  const expected = await hmacHex(env.STRIPE_WEBHOOK_SECRET, `${t}.${raw}`);
  return sigs.some(s => safeEqual(s, expected));
}

export async function stripeWebhook(env, request, ctx) {
  const raw = await request.text();
  if (!(await verifyStripeSignature(env, request.headers.get('Stripe-Signature'), raw))) {
    console.warn('Stripe webhook signature rejected');
    return new Response('invalid signature', { status: 400 });
  }
  const event = JSON.parse(raw);
  const obj = event.data?.object || {};
  if (event.type === 'payment_intent.succeeded') {
    await recordFromIntent(env, ctx, obj).catch(e => { if (!(e instanceof HttpError)) throw e; });
  } else if (event.type === 'charge.refunded') {
    const txn = obj.payment_intent && await env.DB.prepare("SELECT * FROM transactions WHERE provider = 'stripe' AND provider_ref = ?").bind(obj.payment_intent).first();
    // amount_refunded is cumulative, so apply only the part not seen yet
    if (txn) await applyRefund(env, ctx, txn, 'stripe', `${obj.id}:${obj.amount_refunded}`, obj.amount_refunded - txn.refunded_minor);
  } else if (event.type === 'charge.dispute.funds_withdrawn') {
    const txn = obj.payment_intent && await env.DB.prepare("SELECT * FROM transactions WHERE provider = 'stripe' AND provider_ref = ?").bind(obj.payment_intent).first();
    if (txn) await applyRefund(env, ctx, txn, 'stripe', `dispute-${obj.id}`, obj.amount);
  }
  return new Response('ok');
}
