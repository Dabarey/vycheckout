// Shared helpers: responses, crypto, money, validation, rate limiting.

export class HttpError extends Error {
  constructor(status, message, code) { super(message); this.status = status; this.code = code; }
}
export const bad = (msg, code) => new HttpError(400, msg, code);
export const unauthorized = (msg = 'Please sign in') => new HttpError(401, msg, 'unauthorized');
export const forbidden = (msg = 'Not allowed') => new HttpError(403, msg, 'forbidden');
export const notFound = (msg = 'Not found') => new HttpError(404, msg, 'not_found');

export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers },
  });
}

export async function readJson(request, maxBytes = 64 * 1024) {
  const text = await request.text();
  if (text.length > maxBytes) throw bad('Request too large');
  if (!text) return {};
  try {
    const v = JSON.parse(text);
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error();
    return v;
  } catch { throw bad('Invalid JSON'); }
}

export const nowIso = () => new Date().toISOString();
export const newId = () => crypto.randomUUID();

// ── Crypto ──
const enc = new TextEncoder();

export function randomToken(bytes = 32) {
  const a = new Uint8Array(bytes);
  crypto.getRandomValues(a);
  return b64url(a);
}
export function b64url(bytes) {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function b64(bytes) { let s = ''; for (const b of bytes) s += String.fromCharCode(b); return btoa(s); }
function unb64(str) { return Uint8Array.from(atob(str), c => c.charCodeAt(0)); }
export const hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');

export async function sha256Hex(text) {
  return hex(await crypto.subtle.digest('SHA-256', enc.encode(text)));
}
export async function hmacHex(secret, text) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', key, enc.encode(text)));
}
// Constant-time string comparison
export function safeEqual(a, b) {
  a = String(a); b = String(b);
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

// PBKDF2-SHA256. Workers cap PBKDF2 at 100,000 iterations.
const PBKDF2_ITER = 100000;
export async function hashPassword(password) {
  const salt = new Uint8Array(16); crypto.getRandomValues(salt);
  const bits = await pbkdf2(password, salt, PBKDF2_ITER);
  return `pbkdf2$${PBKDF2_ITER}$${b64(salt)}$${b64(bits)}`;
}
export async function verifyPassword(password, stored) {
  if (!stored || !stored.startsWith('pbkdf2$')) return false;
  const [, iter, saltB64, hashB64] = stored.split('$');
  const bits = await pbkdf2(password, unb64(saltB64), parseInt(iter, 10));
  return safeEqual(b64(bits), hashB64);
}
async function pbkdf2(password, salt, iterations) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
}

// ── Money ──
export const CURRENCIES = ['USD','EUR','GBP','AUD','CAD','SGD','JPY','MXN','HKD'];
const ZERO_DECIMAL = ['JPY'];
export const isZeroDecimal = c => ZERO_DECIMAL.includes(c);
export const minorFactor = c => (isZeroDecimal(c) ? 1 : 100);

export function toMinor(amount, currency) {
  const n = Number(amount);
  if (!Number.isFinite(n)) throw bad('Invalid amount');
  return Math.round(n * minorFactor(currency));
}
export const toMajor = (minor, currency) => Number(minor) / minorFactor(currency);
// Decimal string as PayPal wants it ("12.50", or "1500" for JPY)
export function majorString(minor, currency) {
  return isZeroDecimal(currency) ? String(minor) : (minor / 100).toFixed(2);
}

export function cleanCurrency(c) {
  const cur = String(c || 'USD').toUpperCase();
  if (!CURRENCIES.includes(cur)) throw bad('Unsupported currency');
  return cur;
}

// ── Validation ──
export function str(v, { max = 200, required = false, field = 'Field' } = {}) {
  const s = typeof v === 'string' ? v.trim() : (v == null ? '' : String(v).trim());
  if (required && !s) throw bad(`${field} is required`);
  if (s.length > max) throw bad(`${field} is too long (max ${max} characters)`);
  return s;
}
export function emailOf(v) {
  const e = str(v, { max: 254, required: true, field: 'Email' }).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw bad('Enter a valid email address');
  return e;
}

// Only public https URLs (blocks localhost, private and link-local addresses)
export function safeWebhookUrl(raw) {
  let u;
  try { u = new URL(raw); } catch { throw bad('Enter a valid URL'); }
  if (u.protocol !== 'https:') throw bad('Webhook URL must start with https://');
  if (u.username || u.password) throw bad('Webhook URL must not contain a username or password');
  const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  const privateHost =
    h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal') ||
    /^(127\.|10\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h) ||
    /^\d+$/.test(h) || h === '::1' || /^f[cd][0-9a-f]{2}:/.test(h) || /^fe80:/.test(h) || h.startsWith('::ffff:');
  if (privateHost) throw bad('Webhook URL must point to a public server');
  if (raw.length > 500) throw bad('Webhook URL is too long');
  return u.toString();
}

// ── Rate limiting (fixed window, stored in D1) ──
export async function rateLimit(env, key, limit, windowMs) {
  const now = Date.now();
  const row = await env.DB.prepare(
    `INSERT INTO rate_limits (key, count, window_start) VALUES (?1, 1, ?2)
     ON CONFLICT(key) DO UPDATE SET
       count = CASE WHEN rate_limits.window_start < ?3 THEN 1 ELSE rate_limits.count + 1 END,
       window_start = CASE WHEN rate_limits.window_start < ?3 THEN ?2 ELSE rate_limits.window_start END
     RETURNING count`
  ).bind(key, now, now - windowMs).first();
  if (row && row.count > limit) throw new HttpError(429, 'Too many attempts. Please wait a few minutes and try again.', 'rate_limited');
}

export const clientIp = request => request.headers.get('CF-Connecting-IP') || 'local';

export async function audit(env, actorId, action, target, details) {
  await env.DB.prepare('INSERT INTO audit_log (id, actor_id, action, target, details) VALUES (?,?,?,?,?)')
    .bind(newId(), actorId || null, action, target || null, details ? JSON.stringify(details) : null).run();
}

// ── Payment hold: how long new credits wait before they can be withdrawn ──
export const holdDays = env => parseFloat(env.HOLD_DAYS || '7');
// Admin override (users.hold_days) wins; accounts younger than NEW_ACCOUNT_DAYS get the longer hold.
export function holdDaysFor(env, u) {
  if (!u) return holdDays(env);
  if (u.hold_days != null) return u.hold_days;
  const ageDays = (Date.now() - new Date(u.created_at).getTime()) / 86400000;
  return ageDays < parseFloat(env.NEW_ACCOUNT_DAYS || '30') ? parseFloat(env.NEW_ACCOUNT_HOLD_DAYS || '14') : holdDays(env);
}
export async function availableAtFor(env, userId) {
  const u = await env.DB.prepare('SELECT hold_days, created_at FROM users WHERE id = ?').bind(userId).first();
  const days = holdDaysFor(env, u);
  return days > 0 ? new Date(Date.now() + days * 86400000).toISOString() : null;
}
